import 'dotenv/config';
import { Beyin, rolBelirle, type Saglayici } from './beyin.js';

// ---------------------------------------------------------------------------------------------------------------------
// Çok sağlayıcılı beyin: Render'da girilen tüm anahtarlar (Gemini, OpenAI, Claude, Grok, Groq, DeepSeek, Mistral, OpenRouter,
// eski LLM_API_KEY/ABACUS_API_KEY) otomatik bulunur. Her sohbet/görüntü isteği işine göre sağlayıcıya yönlenir, model adları
// sağlayıcının kendi listesinden seçilir, hata olursa sıradaki sağlayıcıya geçilir. Ayrıntı: beyin.ts, docs/BEYIN.md
// ---------------------------------------------------------------------------------------------------------------------

export class RouteLLMError extends Error {
  status: number;
  body: string;
  constructor(status: number, body: string) {
    super(`RouteLLM ${status}: ${body.slice(0, 300)}`);
    this.status = status;
    this.body = body;
  }
}

/** Sağlayıcıya göre kimlik başlıkları (Claude'un yerel başlıkları da gönderilir). */
function baslik(s: Pick<Saglayici, 'id' | 'anahtar'>): Record<string, string> {
  const h: Record<string, string> = { Authorization: `Bearer ${s.anahtar}`, 'Content-Type': 'application/json' };
  if (s.id === 'anthropic') { h['x-api-key'] = s.anahtar; h['anthropic-version'] = '2023-06-01'; }
  return h;
}

async function modelListesi(s: Saglayici): Promise<string[]> {
  const r = await fetch(`${s.url}/models${s.id === 'anthropic' ? '?limit=1000' : ''}`, { headers: baslik(s), signal: AbortSignal.timeout(8000) });
  if (!r.ok) throw new RouteLLMError(r.status, await r.text());
  const j = (await r.json()) as { data?: { id?: string }[]; models?: { name?: string }[] };
  return [...(j.data ?? []).map(m => m.id ?? ''), ...(j.models ?? []).map(m => m.name ?? '')].filter(Boolean);
}

export const BEYIN = new Beyin({ env: process.env, listele: modelListesi, log: m => console.log(m) });

// Eski kod yolları (sağlık denetimi, ses, kitaplık...) için "birincil" bağlantı: sohbet sırasındaki ilk sağlayıcı
const BIRINCIL: Saglayici | undefined = BEYIN.sira('sohbet')[0];
export const BASE_URL = (BIRINCIL?.url ?? 'https://routellm.abacus.ai/v1').replace(/\/+$/, '');
export const API_KEY = BIRINCIL?.anahtar ?? '';
/** Abacus'a özgü varsayılanlar (flux2 görsel, gpt-audio ses...) yalnızca Abacus uçunda geçerli */
export const IS_ABACUS = /abacus\.ai/i.test(BASE_URL);
/** Gemini sağlayıcısı (varsa): Gemini'nin yerel ses modeli için birincil olmasa da kullanılır */
export const GEMINI_SAGLAYICI: Saglayici | undefined = BEYIN.saglayicilar.find(s => s.id === 'gemini');
export const GEMINI = !!GEMINI_SAGLAYICI;
export const MOCK = process.env.MOCK === '1' || BEYIN.bos;

// Model adı: elle yazıldıysa o; değilse sağlayıcı yönlendirmesi kendisi seçer ("otomatik" yalnızca görünen ad)
const ISTENEN_MODEL = (process.env.CHAT_MODEL || '').trim();
export const CHAT_MODEL = ISTENEN_MODEL && !(BIRINCIL && !BIRINCIL.ozel && ISTENEN_MODEL === 'route-llm')
  ? ISTENEN_MODEL
  : !BIRINCIL ? 'route-llm' : BIRINCIL.ozel ? 'route-llm' : BIRINCIL.id === 'gemini' ? 'gemini-3.8-flash' : 'otomatik';

if (BEYIN.saglayicilar.length) {
  console.log(`[beyin] ${BEYIN.saglayicilar.length} sağlayıcı: ${BEYIN.saglayicilar.map(s => s.ad).join(', ')} · mod: ${BEYIN.mod}`);
  for (const r of ['sohbet', 'derin', 'gorsel'] as const) console.log(`[beyin]   ${r}: ${BEYIN.sira(r).map(s => s.id).join(' → ')}`);
}

async function routellmOnce<T = any>(path: string, body?: unknown, method = body ? 'POST' : 'GET', s?: Saglayici): Promise<T> {
  const url = s?.url ?? BASE_URL;
  const res = await fetch(url + path, {
    method,
    headers: baslik(s ?? { id: BIRINCIL?.id ?? '', anahtar: API_KEY }),
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  if (!res.ok) throw new RouteLLMError(res.status, text);
  return JSON.parse(text) as T;
}

/** Bu istek çok sağlayıcılı yönlendirmeye girer mi? (ses/görsel üretimi gibi özel kipler girmez) */
const yonlendirilebilir = (b: Record<string, any>) => !BEYIN.bos && typeof b.model === 'string' && !b.modalities;

export async function routellm<T = any>(path: string, body?: unknown, method = body ? 'POST' : 'GET'): Promise<T> {
  if (path === '/chat/completions' && body && yonlendirilebilir(body as Record<string, any>)) {
    const b = body as Record<string, any>;
    return BEYIN.calistir(rolBelirle(b, BEYIN.mod), b, (s, g) => routellmOnce<T>(path, g, method, s));
  }
  return routellmOnce<T>(path, body, method);
}

/** Kullanıcıya gösterilecek, ne yapılacağını söyleyen Türkçe hata metni */
const NEDEN = (durum: number | null) =>
  durum === 401 || durum === 403 ? 'anahtar geçersiz' : durum === 429 ? 'limit doldu' : durum === 404 ? 'model bulunamadı'
    : durum !== null && durum >= 500 ? 'sunucu yanıt vermiyor' : durum === null ? 'ulaşılamadı' : `hata ${durum}`;

export function friendlyError(e: unknown): string {
  const raw = String((e as Error)?.message ?? e);
  const liste = (e as { saglayicilar?: { ad: string; durum: number | null }[] })?.saglayicilar;
  if (liste && liste.length > 1) {
    return `Hiçbir yapay zekâ sağlayıcısı cevap vermedi: ${liste.map(x => `${x.ad} (${NEDEN(x.durum)})`).join(', ')}. Render → Environment'ta anahtarları kontrol et; Ayarlar → Beyin bölümünde "Beyni dene" hangisinin çalıştığını gösterir.`;
  }
  const ad = liste?.[0]?.ad ?? 'Yapay zekâ';
  if (e instanceof RouteLLMError) {
    const { status, body } = e;
    if (status === 401 || status === 403 || /invalid api key|api key not valid|permission[_ ]denied/i.test(body)) {
      return `${ad} anahtarı geçersiz ya da istek yanlış adrese gidiyor. Render → Environment'ta bu sağlayıcının anahtarını kontrol et (başında/sonunda boşluk olmasın).`;
    }
    if (status === 429) {
      return /limit:\s*0/.test(body)
        ? `${ad} bu modelin ücretsiz kotası yok. Başka bir sağlayıcı anahtarı ekle ya da farklı bir model seç.`
        : `${ad} limiti doldu. Birkaç dakika bekleyip tekrar dene ya da ikinci bir sağlayıcı anahtarı ekle.`;
    }
    if (/model/i.test(body) && /(no longer available|not found|does not exist|not supported)/i.test(body)) {
      return `${ad} modeli artık kullanılamıyor. Model adını elle yazdıysan sil: Jarvis en yenisini kendisi bulur.`;
    }
    if (status >= 500) return `${ad} sunucusu şu an yoğun ya da yanıt vermiyor. Birazdan tekrar dene.`;
    return `${ad} isteği reddedildi (${status}): ${body.replace(/\s+/g, ' ').slice(0, 160)}`;
  }
  if (/fetch failed|ECONN|ENOTFOUND|ETIMEDOUT|network/i.test(raw)) return 'Yapay zekâ sunucusuna ulaşılamadı. İnternet bağlantısını kontrol et.';
  return raw;
}

export interface StreamResult {
  content: string;
  tool_calls: NonNullable<ChatMessage['tool_calls']>;
  model: string | null;
  /** İsteğin gönderilmesinden ilk içerik/araç parçasına kadar geçen süre */
  firstTokenMs: number | null;
  totalMs: number;
}

/**
 * Akışlı sohbet isteği (`stream: true`). İçerik geldikçe `onContent` çağrılır; araç çağrıları parçalardan birleştirilir.
 * Sahne JSON'u bu sayede tamamı bitmeden okunmaya başlar (ilk sahne hazır olunca TTS'i başlar).
 * Akış başlamadan hata olursa sıradaki sağlayıcıya geçilir; içerik akmaya başladıktan sonra geçilmez.
 */
export function routellmStream(body: object, onContent?: (delta: string, full: string) => void): Promise<StreamResult> {
  const b = body as Record<string, any>;
  if (yonlendirilebilir(b)) return BEYIN.calistir(rolBelirle(b, BEYIN.mod), b, (s, g) => routellmStreamOnce(g, onContent, s));
  return routellmStreamOnce(b, onContent);
}

async function routellmStreamOnce(body: object, onContent?: (delta: string, full: string) => void, s?: Saglayici): Promise<StreamResult> {
  const t0 = performance.now();
  const res = await fetch((s?.url ?? BASE_URL) + '/chat/completions', {
    method: 'POST',
    headers: baslik(s ?? { id: BIRINCIL?.id ?? '', anahtar: API_KEY }),
    body: JSON.stringify({ ...body, stream: true }),
  });
  if (!res.ok || !res.body) throw new RouteLLMError(res.status, await res.text());
  const dec = new TextDecoder();
  let buf = '';
  let content = '';
  let model: string | null = null;
  let firstTokenMs: number | null = null;
  const calls: { id: string; name: string; args: string }[] = [];
  const slotOf = new Map<number, number>();
  try {
    for await (const chunk of res.body as unknown as AsyncIterable<Uint8Array>) {
      buf += dec.decode(chunk, { stream: true });
      let nl: number;
      while ((nl = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, nl).trim();
        buf = buf.slice(nl + 1);
        if (!line.startsWith('data:')) continue;
        const data = line.slice(5).trim();
        if (!data || data === '[DONE]') continue;
        let j: any;
        try { j = JSON.parse(data); } catch { continue; }
        model ??= j.model ?? null;
        const d = j.choices?.[0]?.delta ?? {};
        if ((d.content || d.tool_calls) && firstTokenMs === null) firstTokenMs = Math.round(performance.now() - t0);
        for (const tc of d.tool_calls ?? []) {
          // Gemini gibi bazı OpenAI-uyumlu uçlar paralel çağrıların hepsine index 0 verir: aynı ham indekste kimlik
          // değiştiyse yeni çağrıdır. Kimliksiz devam parçaları, o ham indeksin en son yuvasına eklenir.
          const raw = tc.index ?? 0;
          let i = slotOf.get(raw);
          if (i === undefined || (tc.id && calls[i]?.id && calls[i].id !== tc.id)) { i = calls.length; slotOf.set(raw, i); }
          calls[i] ??= { id: '', name: '', args: '' };
          if (tc.id) calls[i].id = tc.id;
          if (tc.function?.name) calls[i].name += tc.function.name;
          if (tc.function?.arguments) calls[i].args += tc.function.arguments;
        }
        if (typeof d.content === 'string' && d.content) {
          content += d.content;
          onContent?.(d.content, content);
        }
      }
    }
  } catch (e) {
    if (firstTokenMs !== null && e && typeof e === 'object') (e as { kismi?: boolean }).kismi = true; // içerik akmaya başladı: başka sağlayıcıya geçme
    throw e;
  }
  return {
    content,
    tool_calls: calls.filter(Boolean).map((c, i) => ({ id: c.id || `call_${i}`, type: 'function' as const, function: { name: c.name, arguments: c.args } })),
    model,
    firstTokenMs,
    totalMs: Math.round(performance.now() - t0),
  };
}

// ---------------------------------------------------------------------------------------------------------------------
// "Beyni dene": her sağlayıcıya küçük bir istek atıp anahtarın ve modelin çalıştığını gösterir.
// ---------------------------------------------------------------------------------------------------------------------
export interface DeneSonucu { id: string; ad: string; ok: boolean; ms: number; model: string | null; hata?: string }

export async function beyniDene(): Promise<DeneSonucu[]> {
  return Promise.all(BEYIN.saglayicilar.map(async (s): Promise<DeneSonucu> => {
    const t0 = performance.now();
    const gecen = () => Math.round(performance.now() - t0);
    try {
      const model = await BEYIN.modelSec(s, 'sohbet', true);
      const govde = { messages: [{ role: 'user', content: 'Sadece "tamam" yaz.' }], max_tokens: 24 };
      const gonder = (reasoning: boolean) => {
        const g = BEYIN.uyarla(s, govde, model);
        if (!reasoning) delete g.reasoning_effort;
        return Promise.race([
          routellmOnce<ChatResponse>('/chat/completions', g, 'POST', s),
          new Promise<never>((_, red) => setTimeout(() => red(new RouteLLMError(408, 'zaman aşımı (20 sn)')), 20_000)),
        ]);
      };
      let r: ChatResponse;
      try { r = await gonder(true); }
      catch (e) {
        if (e instanceof RouteLLMError && e.status === 400 && /reasoning|thinking/i.test(e.body)) r = await gonder(false);
        else throw e;
      }
      return { id: s.id, ad: s.ad, ok: true, ms: gecen(), model: r.model ?? model ?? 'olduğu gibi' };
    } catch (e) {
      const durum = e instanceof RouteLLMError ? e.status : null;
      const ayrinti = e instanceof RouteLLMError ? e.body.replace(/\s+/g, ' ').slice(0, 120) : String((e as Error)?.message ?? e).slice(0, 120);
      return { id: s.id, ad: s.ad, ok: false, ms: gecen(), model: null, hata: `${NEDEN(durum)} · ${ayrinti}` };
    }
  }));
}

export type ContentPart =
  | { type: 'text'; text: string }
  | { type: 'image_url'; image_url: { url: string } }
  | { type: 'input_audio'; input_audio: { data: string; format: string } };

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant' | 'tool';
  content: string | null | ContentPart[];
  tool_calls?: { id: string; type: 'function'; function: { name: string; arguments: string } }[];
  tool_call_id?: string;
}

export interface ChatResponse {
  model?: string;
  choices: {
    message: ChatMessage & {
      audio?: { data: string };
      audios?: { id: string; data: string; expires_at: number; transcript: string }[];
    };
    finish_reason: string;
  }[];
}
