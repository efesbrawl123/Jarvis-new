// Küçük, kesin hesap araçları (model bunları tahmin etmesin diye). Ağ gerektirmeyenler saf fonksiyondur.
import { randomInt } from 'node:crypto';

const TR_HARF: Record<string, string> = { 'İ': 'i', 'I': 'i', 'ı': 'i', 'ş': 's', 'Ş': 's', 'ğ': 'g', 'Ğ': 'g', 'ü': 'u', 'Ü': 'u', 'ö': 'o', 'Ö': 'o', 'ç': 'c', 'Ç': 'c' };
const sade = (s: string) => s.replace(/[İIışŞğĞüÜöÖçÇ]/g, c => TR_HARF[c] ?? c).toLowerCase();
const yuvarla = (x: number, hane = 10) => Number(x.toPrecision(hane));

// ------------------------------------------------------------------ 1) Birim çevirme
interface Birim { kat: string; carpan: number }
const B: Record<string, Birim> = {};
const ekle = (kat: string, carpan: number, ...adlar: string[]) => { for (const a of adlar) B[a] = { kat, carpan }; };
ekle('uzunluk', 1, 'm', 'metre'); ekle('uzunluk', 1000, 'km', 'kilometre'); ekle('uzunluk', 0.01, 'cm', 'santimetre');
ekle('uzunluk', 0.001, 'mm', 'milimetre'); ekle('uzunluk', 1609.344, 'mil', 'mile', 'mi'); ekle('uzunluk', 0.3048, 'ft', 'ayak', 'foot', 'feet');
ekle('uzunluk', 0.0254, 'in', 'inc', 'inch', 'parmak'); ekle('uzunluk', 0.9144, 'yd', 'yard'); ekle('uzunluk', 1852, 'nmi', 'denizmili');
ekle('kutle', 1, 'kg', 'kilogram', 'kilo'); ekle('kutle', 0.001, 'g', 'gram'); ekle('kutle', 1e-6, 'mg', 'miligram'); ekle('kutle', 1000, 'ton');
ekle('kutle', 0.45359237, 'lb', 'pound', 'libre'); ekle('kutle', 0.028349523125, 'oz', 'ounce');
ekle('hacim', 1, 'l', 'lt', 'litre'); ekle('hacim', 0.001, 'ml', 'mililitre'); ekle('hacim', 1000, 'm3', 'metrekup');
ekle('hacim', 3.785411784, 'gal', 'galon', 'gallon'); ekle('hacim', 0.2365882365, 'cup', 'fincan'); ekle('hacim', 0.0295735295625, 'floz');
ekle('hiz', 1, 'ms', 'm/s', 'mps'); ekle('hiz', 1 / 3.6, 'kmh', 'km/h', 'km/s', 'km/sa', 'kmsa'); ekle('hiz', 0.44704, 'mph');
ekle('hiz', 1852 / 3600, 'knot', 'dugum', 'kt');
ekle('alan', 1, 'm2', 'metrekare'); ekle('alan', 1e6, 'km2', 'kilometrekare'); ekle('alan', 1e4, 'ha', 'hektar'); ekle('alan', 1000, 'donum');
ekle('alan', 4046.8564224, 'acre'); ekle('alan', 0.09290304, 'ft2'); ekle('alan', 0.0001, 'cm2');
ekle('zaman', 1, 'sn', 'saniye', 's'); ekle('zaman', 60, 'dk', 'dakika'); ekle('zaman', 3600, 'saat', 'sa'); ekle('zaman', 86400, 'gun');
ekle('zaman', 604800, 'hafta'); ekle('zaman', 2629800, 'ay'); ekle('zaman', 31557600, 'yil');
const SICAKLIK = new Set(['c', 'celsius', 'santigrat', 'f', 'fahrenheit', 'k', 'kelvin']);
const birimAdi = (s: string) => sade(s).replace(/[°\s.]/g, '').replace('²', '2').replace('³', '3').replace(/^sicaklik/, '');

export function birimCevir(deger: number, kaynak: string, hedef: string): { deger: number; kaynak: string; hedef: string; sonuc: number; kategori: string } {
  if (!Number.isFinite(deger)) throw new Error('Değer sayı olmalı');
  const a = birimAdi(kaynak), b = birimAdi(hedef);
  if (SICAKLIK.has(a) || SICAKLIK.has(b)) {
    if (!(SICAKLIK.has(a) && SICAKLIK.has(b))) throw new Error('Sıcaklık yalnızca sıcaklığa çevrilir');
    const c = /^c|^s/.test(a) ? deger : /^f/.test(a) ? ((deger - 32) * 5) / 9 : deger - 273.15;
    const sonuc = /^c|^s/.test(b) ? c : /^f/.test(b) ? (c * 9) / 5 + 32 : c + 273.15;
    return { deger, kaynak, hedef, sonuc: yuvarla(sonuc), kategori: 'sıcaklık' };
  }
  const ba = B[a], bb = B[b];
  if (!ba) throw new Error(`Bilinmeyen birim: ${kaynak}`);
  if (!bb) throw new Error(`Bilinmeyen birim: ${hedef}`);
  if (ba.kat !== bb.kat) throw new Error(`${kaynak} (${ba.kat}) ile ${hedef} (${bb.kat}) birbirine çevrilemez`);
  return { deger, kaynak, hedef, sonuc: yuvarla((deger * ba.carpan) / bb.carpan), kategori: ba.kat };
}

// ------------------------------------------------------------------ 2) Tarih hesapları
const GUNLER = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
const AYLAR = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
const GUN_MS = 86400000;

export function tarihCoz(s: string): number {
  const m = /^\s*(\d{4})-(\d{1,2})-(\d{1,2})\s*$/.exec(s) ?? ((x) => (x ? [x[0], x[3], x[2], x[1]] : null))(/^\s*(\d{1,2})[./](\d{1,2})[./](\d{4})\s*$/.exec(s));
  if (!m) throw new Error(`Tarih anlaşılamadı: "${s}" (YYYY-AA-GG ya da GG.AA.YYYY yaz)`);
  const y = Number(m[1]), ay = Number(m[2]), g = Number(m[3]);
  const t = Date.UTC(y, ay - 1, g);
  const d = new Date(t);
  if (d.getUTCFullYear() !== y || d.getUTCMonth() !== ay - 1 || d.getUTCDate() !== g) throw new Error(`Geçersiz tarih: ${s}`);
  return t;
}
const yaz = (t: number) => { const d = new Date(t); return `${d.getUTCDate()} ${AYLAR[d.getUTCMonth()]} ${d.getUTCFullYear()} ${GUNLER[d.getUTCDay()]}`; };
const iso = (t: number) => new Date(t).toISOString().slice(0, 10);

/** İstanbul'daki bugünün tarihi (UTC gece yarısı olarak). */
export function bugunIstanbul(now = new Date()): number {
  const p: Record<string, string> = {};
  for (const x of new Intl.DateTimeFormat('en-GB', { timeZone: 'Europe/Istanbul', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(now)) p[x.type] = x.value;
  return Date.UTC(Number(p.year), Number(p.month) - 1, Number(p.day));
}

function takvimFarki(a: number, b: number) { // a <= b
  const da = new Date(a), db = new Date(b);
  let y = db.getUTCFullYear() - da.getUTCFullYear(), m = db.getUTCMonth() - da.getUTCMonth(), g = db.getUTCDate() - da.getUTCDate();
  if (g < 0) { m--; g += new Date(Date.UTC(db.getUTCFullYear(), db.getUTCMonth(), 0)).getUTCDate(); }
  if (m < 0) { y--; m += 12; }
  return { yil: y, ay: m, gun: g };
}

export function tarihHesapla(a: { islem: string; tarih1?: string; tarih2?: string; gun?: number }, now = new Date()): Record<string, unknown> {
  const bugun = bugunIstanbul(now);
  switch (a.islem) {
    case 'fark': {
      const t1 = tarihCoz(a.tarih1 ?? ''), t2 = tarihCoz(a.tarih2 ?? '');
      const fark = Math.round((t2 - t1) / GUN_MS);
      const [x, y] = t1 <= t2 ? [t1, t2] : [t2, t1];
      return { islem: 'fark', tarih1: yaz(t1), tarih2: yaz(t2), gun_farki: fark, hafta: Math.trunc(fark / 7), kalan_gun: Math.abs(fark) % 7, takvim: takvimFarki(x, y) };
    }
    case 'ekle': {
      const t1 = tarihCoz(a.tarih1 ?? iso(bugun));
      const n = Math.trunc(Number(a.gun));
      if (!Number.isFinite(n) || Math.abs(n) > 365000) throw new Error('gun sayısı geçersiz');
      const s = t1 + n * GUN_MS;
      return { islem: 'ekle', baslangic: yaz(t1), eklenen_gun: n, sonuc: yaz(s), sonuc_iso: iso(s) };
    }
    case 'haftanin_gunu': {
      const t1 = tarihCoz(a.tarih1 ?? '');
      return { islem: 'haftanin_gunu', tarih: yaz(t1), gun: GUNLER[new Date(t1).getUTCDay()] };
    }
    case 'kalan_gun': {
      const t1 = tarihCoz(a.tarih1 ?? '');
      const fark = Math.round((t1 - bugun) / GUN_MS);
      return { islem: 'kalan_gun', bugun: yaz(bugun), hedef: yaz(t1), kalan_gun: fark, aciklama: fark > 0 ? `${fark} gün kaldı` : fark === 0 ? 'bugün' : `${-fark} gün önceydi` };
    }
    case 'yas': {
      const t1 = tarihCoz(a.tarih1 ?? '');
      if (t1 > bugun) throw new Error('Doğum tarihi gelecekte');
      return { islem: 'yas', dogum: yaz(t1), bugun: yaz(bugun), yas: takvimFarki(t1, bugun), toplam_gun: Math.round((bugun - t1) / GUN_MS) };
    }
    default: throw new Error('islem: fark, ekle, haftanin_gunu, kalan_gun ya da yas olmalı');
  }
}

// ------------------------------------------------------------------ 3) Rastgele
export function rastgele(a: { tur: string; adet?: number; yuz?: number; min?: number; max?: number; secenekler?: string[] }): Record<string, unknown> {
  switch (a.tur) {
    case 'zar': {
      const adet = Math.min(10, Math.max(1, Math.trunc(a.adet ?? 1))), yuz = Math.min(100, Math.max(2, Math.trunc(a.yuz ?? 6)));
      const at = Array.from({ length: adet }, () => randomInt(1, yuz + 1));
      return { tur: 'zar', yuz, sonuclar: at, toplam: at.reduce((x, y) => x + y, 0) };
    }
    case 'yazi_tura': return { tur: 'yazı tura', sonuc: randomInt(0, 2) === 0 ? 'Yazı' : 'Tura' };
    case 'sayi': {
      const min = Math.trunc(a.min ?? 1), max = Math.trunc(a.max ?? 100);
      if (!(max >= min) || max - min > 2 ** 40) throw new Error('min ve max geçersiz');
      return { tur: 'sayı', min, max, sonuc: randomInt(min, max + 1) };
    }
    case 'secim': {
      const s = (a.secenekler ?? []).map(String).filter(Boolean);
      if (s.length < 2) throw new Error('En az iki seçenek gerekli');
      return { tur: 'seçim', secenekler: s, sonuc: s[randomInt(0, s.length)] };
    }
    default: throw new Error('tur: zar, yazi_tura, sayi ya da secim olmalı');
  }
}

// ------------------------------------------------------------------ 4) Dünya saati
const SEHIRLER: Record<string, string> = {
  istanbul: 'Europe/Istanbul', ankara: 'Europe/Istanbul', izmir: 'Europe/Istanbul', turkiye: 'Europe/Istanbul', londra: 'Europe/London', london: 'Europe/London',
  paris: 'Europe/Paris', berlin: 'Europe/Berlin', roma: 'Europe/Rome', madrid: 'Europe/Madrid', lizbon: 'Europe/Lisbon', amsterdam: 'Europe/Amsterdam',
  atina: 'Europe/Athens', moskova: 'Europe/Moscow', kiev: 'Europe/Kyiv', varsova: 'Europe/Warsaw', stockholm: 'Europe/Stockholm', dublin: 'Europe/Dublin',
  dubai: 'Asia/Dubai', tahran: 'Asia/Tehran', bagdat: 'Asia/Baghdad', riyad: 'Asia/Riyadh', kudus: 'Asia/Jerusalem', delhi: 'Asia/Kolkata', mumbai: 'Asia/Kolkata',
  karachi: 'Asia/Karachi', dakka: 'Asia/Dhaka', bangkok: 'Asia/Bangkok', cakarta: 'Asia/Jakarta', singapur: 'Asia/Singapore', 'hong kong': 'Asia/Hong_Kong',
  pekin: 'Asia/Shanghai', sanghay: 'Asia/Shanghai', seul: 'Asia/Seoul', tokyo: 'Asia/Tokyo', sidney: 'Australia/Sydney', melburn: 'Australia/Melbourne',
  auckland: 'Pacific/Auckland', 'new york': 'America/New_York', newyork: 'America/New_York', washington: 'America/New_York', chicago: 'America/Chicago',
  denver: 'America/Denver', 'los angeles': 'America/Los_Angeles', losangeles: 'America/Los_Angeles', 'san francisco': 'America/Los_Angeles', toronto: 'America/Toronto',
  vancouver: 'America/Vancouver', meksika: 'America/Mexico_City', 'sao paulo': 'America/Sao_Paulo', 'buenos aires': 'America/Argentina/Buenos_Aires',
  kahire: 'Africa/Cairo', lagos: 'Africa/Lagos', nairobi: 'Africa/Nairobi', johannesburg: 'Africa/Johannesburg', kazablanka: 'Africa/Casablanca', honolulu: 'Pacific/Honolulu',
};
function sapmaDk(tz: string, d: Date): number {
  const p: Record<string, string> = {};
  for (const x of new Intl.DateTimeFormat('en-GB', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' }).formatToParts(d)) p[x.type] = x.value;
  const yerel = Date.UTC(Number(p.year), Number(p.month) - 1, Number(p.day), Number(p.hour), Number(p.minute), Number(p.second));
  return Math.round((yerel - Math.floor(d.getTime() / 1000) * 1000) / 60000);
}
export function dunyaSaati(sehir: string, now = new Date()): Record<string, unknown> {
  const anahtar = sade(sehir).replace(/\s+/g, ' ').trim();
  let tz = SEHIRLER[anahtar] ?? SEHIRLER[anahtar.replace(/ /g, '')];
  if (!tz && /^[A-Za-z]+\/[A-Za-z_]+/.test(sehir.trim())) tz = sehir.trim();
  if (!tz) throw new Error(`"${sehir}" şehrini bilmiyorum; büyük şehirlerden birini dene`);
  try { new Intl.DateTimeFormat('en-GB', { timeZone: tz }); } catch { throw new Error(`Saat dilimi geçersiz: ${tz}`); }
  const f = new Intl.DateTimeFormat('tr-TR', { timeZone: tz, hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(now);
  const tarih = new Intl.DateTimeFormat('tr-TR', { timeZone: tz, day: 'numeric', month: 'long', weekday: 'long' }).format(now);
  const fark = (sapmaDk(tz, now) - sapmaDk('Europe/Istanbul', now)) / 60;
  return { sehir, saat: f, tarih, istanbul_farki_saat: fark, aciklama: fark === 0 ? 'İstanbul ile aynı saat' : `İstanbul'dan ${Math.abs(fark)} saat ${fark > 0 ? 'ileride' : 'geride'}` };
}

// ------------------------------------------------------------------ 5) Ay evresi
const SINODIK = 29.530588853;
const YENI_AY_2000 = Date.UTC(2000, 0, 6, 18, 14);
export function ayEvresi(tarih?: string, now = new Date()): Record<string, unknown> {
  const t = tarih ? tarihCoz(tarih) + 12 * 3600000 : now.getTime();
  const faz = ((((t - YENI_AY_2000) / 86400000) / SINODIK) % 1 + 1) % 1;
  const yas = faz * SINODIK;
  const aydinlik = Math.round(((1 - Math.cos(2 * Math.PI * faz)) / 2) * 100);
  const bolge = Math.floor(((faz + 1 / 16) % 1) * 8);
  const ad = ['Yeni Ay', 'Büyüyen hilal', 'İlk dördün', 'Büyüyen şişkin ay', 'Dolunay', 'Küçülen şişkin ay', 'Son dördün', 'Küçülen hilal'][bolge];
  const sonraki = (hedefFaz: number) => { const k = ((hedefFaz - faz) % 1 + 1) % 1; return iso(t + k * SINODIK * 86400000); };
  return { tarih: iso(t), evre: ad, aydinlik_yuzde: aydinlik, ay_yasi_gun: yuvarla(yas, 3), sonraki_dolunay: sonraki(0.5), sonraki_yeni_ay: sonraki(0), not: 'Yaklaşık hesap (±1 gün)' };
}

// ------------------------------------------------------------------ 6) Kredi / taksit
export function krediHesapla(a: { anapara: number; aylik_faiz_yuzde: number; vade_ay: number }): Record<string, unknown> {
  const P = Number(a.anapara), r = Number(a.aylik_faiz_yuzde) / 100, n = Math.trunc(Number(a.vade_ay));
  if (!(P > 0) || !(r >= 0) || !(n >= 1) || n > 600 || r > 1) throw new Error('anapara > 0, aylık faiz 0–100 (yüzde), vade 1–600 ay olmalı');
  const taksit = r === 0 ? P / n : (P * r) / (1 - Math.pow(1 + r, -n));
  const toplam = taksit * n;
  const t = (x: number) => Math.round(x * 100) / 100;
  return { anapara: P, aylik_faiz_yuzde: r * 100, vade_ay: n, aylik_taksit: t(taksit), toplam_odeme: t(toplam), toplam_faiz: t(toplam - P), not: 'KKDF, BSMV, masraf ve sigorta dahil değil; bankanın teklifi farklı olabilir' };
}

// ------------------------------------------------------------------ 7) Uyku döngüsü (90 dk)
const hhmm = (dk: number) => { const x = ((dk % 1440) + 1440) % 1440; return `${String(Math.floor(x / 60)).padStart(2, '0')}:${String(x % 60).padStart(2, '0')}`; };
function saatDk(s: string): number {
  const m = /^\s*(\d{1,2})[:.](\d{2})\s*$/.exec(s);
  if (!m || Number(m[1]) > 23 || Number(m[2]) > 59) throw new Error(`Saat anlaşılamadı: "${s}" (ör. 07:00)`);
  return Number(m[1]) * 60 + Number(m[2]);
}
export function uykuHesapla(a: { kalkis?: string; yatis?: string }): Record<string, unknown> {
  const UYUMA = 15;
  if (a.kalkis) {
    const k = saatDk(a.kalkis);
    return { kalkis: hhmm(k), yatis_onerileri: [6, 5, 4, 3].map(c => ({ dongu: c, yatis: hhmm(k - c * 90 - UYUMA), uyku_suresi: `${(c * 1.5).toString().replace('.', ',')} saat` })), not: 'Uykuya dalmak için 15 dk ayrıldı; 5–6 döngü (7,5–9 saat) idealdir' };
  }
  if (a.yatis) {
    const y = saatDk(a.yatis);
    return { yatis: hhmm(y), kalkis_onerileri: [3, 4, 5, 6].map(c => ({ dongu: c, kalkis: hhmm(y + UYUMA + c * 90), uyku_suresi: `${(c * 1.5).toString().replace('.', ',')} saat` })), not: 'Uykuya dalmak için 15 dk ayrıldı' };
  }
  throw new Error('kalkis ya da yatis saati ver');
}

// ------------------------------------------------------------------ 8) Burç
// Takvim sırasıyla başlangıç tarihleri; 20 Ocak'tan önce ve 22 Aralık'tan sonra Oğlak
const BURCLAR: [string, number, number][] = [
  ['Kova', 1, 20], ['Balık', 2, 19], ['Koç', 3, 21], ['Boğa', 4, 20], ['İkizler', 5, 21], ['Yengeç', 6, 21],
  ['Aslan', 7, 23], ['Başak', 8, 23], ['Terazi', 9, 23], ['Akrep', 10, 23], ['Yay', 11, 22], ['Oğlak', 12, 22],
];
export function burcBul(gun: number, ay: number): Record<string, unknown> {
  const g = Math.trunc(gun), a = Math.trunc(ay);
  if (!(a >= 1 && a <= 12) || !(g >= 1 && g <= new Date(Date.UTC(2024, a, 0)).getUTCDate())) throw new Error('Geçersiz gün/ay');
  let burc = 'Oğlak';
  for (const [ad, m, d] of BURCLAR) if (a > m || (a === m && g >= d)) burc = ad;
  return { gun: g, ay: AYLAR[a - 1], burc };
}

// ------------------------------------------------------------------ 9) Sayıyı yazıya
const BIR = ['', 'bir', 'iki', 'üç', 'dört', 'beş', 'altı', 'yedi', 'sekiz', 'dokuz'];
const ON = ['', 'on', 'yirmi', 'otuz', 'kırk', 'elli', 'altmış', 'yetmiş', 'seksen', 'doksan'];
const BASAMAK = ['', 'bin', 'milyon', 'milyar', 'trilyon', 'katrilyon'];
function ucluk(n: number): string {
  const y = Math.floor(n / 100), o = Math.floor((n % 100) / 10), b = n % 10;
  return [y === 0 ? '' : y === 1 ? 'yüz' : `${BIR[y]} yüz`, ON[o], BIR[b]].filter(Boolean).join(' ');
}
export function sayiYaziya(sayi: number): string {
  if (!Number.isInteger(sayi) || Math.abs(sayi) > 999_999_999_999_999) throw new Error('Yalnızca tam sayı (en çok 999 trilyon)');
  if (sayi === 0) return 'sıfır';
  const eksi = sayi < 0; let n = Math.abs(sayi);
  const parcalar: string[] = [];
  for (let i = 0; n > 0; i++, n = Math.floor(n / 1000)) {
    const g = n % 1000;
    if (!g) continue;
    const metin = i === 1 && g === 1 ? '' : ucluk(g); // "bir bin" değil "bin"
    parcalar.unshift([metin, BASAMAK[i]].filter(Boolean).join(' '));
  }
  return (eksi ? 'eksi ' : '') + parcalar.join(' ');
}

// ------------------------------------------------------------------ 10) Son depremler (USGS)
export async function sonDepremler(a: { min_buyukluk?: number; adet?: number }): Promise<Record<string, unknown>> {
  const min = Math.min(8, Math.max(2.5, Number(a.min_buyukluk ?? 4)));
  const adet = Math.min(10, Math.max(1, Math.trunc(Number(a.adet ?? 5))));
  const url = `https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&minmagnitude=${min}&limit=${adet}&orderby=time&minlatitude=35.5&maxlatitude=42.5&minlongitude=25.5&maxlongitude=45`;
  const ctl = new AbortController();
  const zamanAsimi = setTimeout(() => ctl.abort(), 8000);
  try {
    const r = await fetch(url, { signal: ctl.signal });
    if (!r.ok) return { hata: `Deprem verisi alınamadı (${r.status}). Veri uydurma; alınamadığını söyle.` };
    const j = (await r.json()) as { features?: { properties?: { mag?: number; place?: string; time?: number }; geometry?: { coordinates?: number[] } }[] };
    const liste = (j.features ?? []).map(f => ({
      yer: String(f.properties?.place ?? '?'), buyukluk: f.properties?.mag ?? null, derinlik_km: f.geometry?.coordinates?.[2] ?? null,
      zaman: f.properties?.time ? new Intl.DateTimeFormat('tr-TR', { timeZone: 'Europe/Istanbul', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(new Date(f.properties.time)) : null,
    }));
    return { min_buyukluk: min, adet: liste.length, depremler: liste, kaynak: 'USGS (Türkiye çevresi); AFAD ve Kandilli daha ayrıntılı ve daha küçük depremleri de verir' };
  } catch {
    return { hata: 'Deprem servisine ulaşılamadı. Veri uydurma; alınamadığını söyle.' };
  } finally {
    clearTimeout(zamanAsimi);
  }
}
