// Yedek: ücretsiz sunucu uyuyunca hafıza, profil, kitaplık ve konuşma geçmişi silinir. Bu cihaz kendi kopyasını
// tarayıcıda saklar; sunucu boş (taze) açılınca geri yükler. Sunucu eski sürümdeyse (uç noktalar yok) sessizce atlar.
import { token } from './api';

const KEY = 'jarvis.yedek.v1';
const KEY_ESKI = 'jarvis.yedek.eski';

interface Zarf { v: number; at: string; dosyalar: Record<string, string> }

const baslik = (): HeadersInit => ({ 'Content-Type': 'application/json', ...(token ? { 'x-jarvis-token': token } : {}) });
function oku(k: string): string | null { try { return localStorage.getItem(k); } catch { return null; } }
function yaz(k: string, v: string): boolean { try { localStorage.setItem(k, v); return true; } catch { return false; } }
function coz(raw: string | null): Zarf | null {
  if (!raw) return null;
  try {
    const z = JSON.parse(raw) as Zarf;
    return z && z.v === 1 && z.dosyalar && typeof z.dosyalar === 'object' ? z : null;
  } catch { return null; }
}
function mesajVarMi(z: Zarf): boolean {
  try {
    const s = JSON.parse(z.dosyalar['state.json'] ?? '{}') as { messages?: unknown[] };
    return Array.isArray(s.messages) && s.messages.length > 0;
  } catch { return false; }
}
/** Gerçek veri var mı? Boş (taze) sunucunun yedeği yerel yedeğin üstüne yazılmasın. */
function icerikVarMi(z: Zarf): boolean {
  return Object.keys(z.dosyalar).some(f => f !== 'state.json' && f !== 'home.json') || mesajVarMi(z);
}

let hazir: Promise<boolean> = Promise.resolve(false);

/** Sunucu boş açıldıysa yerel yedeği geri yükler. Başarılıysa true. Hata verirse false döner, atmaz. */
export function restoreIfFresh(): Promise<boolean> {
  hazir = (async () => {
    try {
      const d = await fetch('/api/yedek/durum', { headers: baslik() });
      if (!d.ok) return false;
      const j = (await d.json()) as { taze?: boolean };
      if (!j.taze) return false;
      const z = coz(oku(KEY)) ?? coz(oku(KEY_ESKI));
      if (!z || !icerikVarMi(z)) return false;
      const r = await fetch('/api/yedek/geri', { method: 'POST', headers: baslik(), body: JSON.stringify(z) });
      return r.ok;
    } catch { return false; }
  })();
  return hazir;
}

async function yedekle(): Promise<void> {
  await hazir;
  try {
    const r = await fetch('/api/yedek', { headers: baslik() });
    if (!r.ok) return;
    const y = (await r.json()) as Zarf;
    if (!y || y.v !== 1 || !y.dosyalar || !icerikVarMi(y)) return;
    const eski = coz(oku(KEY));
    if (eski && JSON.stringify(eski.dosyalar) === JSON.stringify(y.dosyalar)) return;
    const ham = oku(KEY);
    let yeni = JSON.stringify(y);
    // Yedek keskin küçüldüyse (ör. yanlışlıkla silme) bir önceki kopyayı da sakla
    if (ham && yeni.length < ham.length * 0.5) yaz(KEY_ESKI, ham);
    if (!yaz(KEY, yeni)) {
      // Tarayıcı deposu doldu: en büyük parçayı (kitaplık) çıkarıp bir kez daha dene
      const { ['kitaplik.json']: _atla, ...kalan } = y.dosyalar;
      void _atla;
      yeni = JSON.stringify({ ...y, dosyalar: kalan });
      yaz(KEY, yeni);
    }
  } catch { /* ağ yok ya da sunucu uyuyor: sonraki turda dene */ }
}

/** Açık kaldığı sürece düzenli yedek alır. Dönen fonksiyon durdurur. */
export function startBackupLoop(): () => void {
  const ilk = setTimeout(() => { void yedekle(); }, 4000);
  const aralik = setInterval(() => { void yedekle(); }, 120_000);
  const gizlenince = () => { if (document.visibilityState === 'hidden') void yedekle(); };
  document.addEventListener('visibilitychange', gizlenince);
  return () => {
    clearTimeout(ilk);
    clearInterval(aralik);
    document.removeEventListener('visibilitychange', gizlenince);
  };
}
