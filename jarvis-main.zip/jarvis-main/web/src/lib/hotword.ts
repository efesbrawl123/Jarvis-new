// Canlı dinleme: tuşa basmadan, "Jarvis" deyince aktif olur. Tarayıcının konuşma tanımasını sürekli açık tutar
// (Chrome/Edge/Android'de iyi; iPhone Safari'de sınırlı). Ses tanıma tarayıcı üreticisinin sunucusunda yapılır.
// Mantık saf tutuldu: tanıyıcı ve zamanlayıcı dışarıdan verilir, böylece sahte mikrofonla sınanır.

const HEDEF = 'jarvis';

/** Türkçe harfleri sadeleştir: "Çarvıs" → "carvis". */
export function katla(s: string): string {
  return s.toLocaleLowerCase('tr').replace(/ı/g, 'i').replace(/ç/g, 'c').replace(/ş/g, 's').replace(/ğ/g, 'g').replace(/ö/g, 'o').replace(/ü/g, 'u');
}

function mesafe(a: string, b: string): number {
  const m = a.length, n = b.length;
  const d: number[] = Array.from({ length: n + 1 }, (_, j) => j);
  for (let i = 1; i <= m; i++) {
    let onceki = d[0];
    d[0] = i;
    for (let j = 1; j <= n; j++) {
      const tmp = d[j];
      d[j] = Math.min(d[j] + 1, d[j - 1] + 1, onceki + (a[i - 1] === b[j - 1] ? 0 : 1));
      onceki = tmp;
    }
  }
  return d[n];
}

/** "Jarvis"in tanıyıcıda sık çıkan bozuk biçimleri: carvis, çarvis, jarviz, jarvish, zarvis, yarvis, jarvise... */
function jarvisBenzeri(katli: string): boolean {
  if (katli.length < 5 || katli.length > 8) return false;
  let x = katli.replace(/^(ch|sh|dj|dz|c|z|y|g|h)/, 'j').replace(/w/g, 'v').replace(/(iz|ish|is)$/, 'is');
  if (x.length < 5) return false;
  return mesafe(x, HEDEF) <= 1;
}

export interface Uyan { bulundu: boolean; komut: string }

const DOLGU = /^(hey|hay|ey|selam|merhaba|tamam|peki)$/i;

/** Metinde "Jarvis" geçiyor mu? Geçiyorsa komut: sonrasındaki söz (yoksa öncesindeki, "hey" gibi dolgular atılarak). */
export function jarvisAra(metin: string): Uyan {
  const toks = [...metin.matchAll(/[\p{L}\p{N}]+/gu)].map(m => ({ s: m[0], i: m.index ?? 0, e: (m.index ?? 0) + m[0].length, f: katla(m[0]) }));
  for (let k = 0; k < toks.length; k++) {
    let son = -1;
    if (jarvisBenzeri(toks[k].f)) son = k;
    else if (k + 1 < toks.length && toks[k + 1].i - toks[k].e <= 2 && jarvisBenzeri(toks[k].f + toks[k + 1].f)) son = k + 1; // "jar vis"
    if (son < 0) continue;
    let bas = toks[son].e;
    // "Jarvis'e", "Jarvis'in": kesme işaretinden sonraki ek de atılır
    if (/['’]/.test(metin[bas] ?? '')) {
      const ek = toks[son + 1];
      if (ek && ek.i <= bas + 1) bas = ek.e;
    }
    const sonra = metin.slice(bas).replace(/^[\s,.:;!?'’"-]+/, '').trim();
    const once = metin.slice(0, toks[k].i).split(/\s+/).filter(w => w && !DOLGU.test(w.replace(/[^\p{L}]/gu, ''))).join(' ').trim();
    return { bulundu: true, komut: sonra || once };
  }
  return { bulundu: false, komut: '' };
}

// ------------------------------------------------------------------ Tanıyıcı ve durum makinesi
export interface TanimaBenzeri {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((e: any) => void) | null;
  onerror: ((e: any) => void) | null;
  onend: (() => void) | null;
  start(): void;
  stop(): void;
  abort(): void;
}
export interface Zamanlayici { set(fn: () => void, ms: number): unknown; clear(id: unknown): void }
export type CanliDurum = 'kapali' | 'bekle' | 'dinliyor' | 'takip' | 'durakladi' | 'hata';

export interface CanliSecenek {
  fabrika(): TanimaBenzeri | null;
  onUyandi(): void;
  onMetin(komut: string): void;
  onDurum(d: CanliDurum): void;
  onGecici?(t: string): void;
  onHata?(mesaj: string): void;
  /** Son sözden sonra komutu bitmiş say (ms) */
  sessizlikMs?: number;
  /** Yalnızca "Jarvis" denirse söz bekleme süresi (ms) */
  komutBeklemeMs?: number;
  /** Cevaptan sonra "Jarvis" demeden devam penceresi (ms) */
  takipMs?: number;
  /** Bu süreden uzun oturumu yenile (ms): birikmiş metin büyümesin */
  oturumMs?: number;
  zaman?: Zamanlayici;
}

const GERCEK: Zamanlayici = { set: (fn, ms) => setTimeout(fn, ms), clear: id => clearTimeout(id as ReturnType<typeof setTimeout>) };

export class CanliDinleme {
  private o: Required<Omit<CanliSecenek, 'onGecici' | 'onHata'>> & Pick<CanliSecenek, 'onGecici' | 'onHata'>;
  private rec: TanimaBenzeri | null = null;
  private acik = false;
  private durakli = false;
  private durum: CanliDurum = 'kapali';
  private takipte = false;
  private dinliyor = false;
  private komut = '';
  private tSessiz: unknown = null;
  private tBekle: unknown = null;
  private tTakip: unknown = null;
  private tYeniden: unknown = null;
  private tOturum: unknown = null;
  private ardisikHata = 0;

  constructor(o: CanliSecenek) {
    this.o = {
      sessizlikMs: 1100, komutBeklemeMs: 7000, takipMs: 8000, oturumMs: 55_000, zaman: GERCEK, ...o,
    } as CanliDinleme['o'];
  }

  get durumu(): CanliDurum { return this.durum; }

  private dur(d: CanliDurum) { if (this.durum !== d) { this.durum = d; this.o.onDurum(d); } }
  private temizle(...ids: unknown[]) { for (const id of ids) if (id != null) this.o.zaman.clear(id); }
  private zamanlayicilariSil() {
    this.temizle(this.tSessiz, this.tBekle, this.tTakip, this.tYeniden, this.tOturum);
    this.tSessiz = this.tBekle = this.tTakip = this.tYeniden = this.tOturum = null;
  }

  baslat() {
    if (this.acik) return;
    this.acik = true;
    this.durakli = false;
    this.takipte = false;
    this.dinliyor = false;
    this.komut = '';
    this.dur('bekle');
    this.ac();
  }

  durdur() {
    this.acik = false;
    this.zamanlayicilariSil();
    this.kapat();
    this.dur('kapali');
  }

  /** Jarvis düşünürken/konuşurken: kendi sesini duymasın. */
  duraklat() {
    if (!this.acik) return;
    this.durakli = true;
    this.dinliyor = false;
    this.komut = '';
    this.zamanlayicilariSil();
    this.kapat();
    this.dur('durakladi');
  }

  /** Cevap bitti. takip=true: kısa süre "Jarvis" demeden de konuşabilirsin. */
  devam(takip = false) {
    if (!this.acik) return;
    this.durakli = false;
    this.dinliyor = false;
    this.komut = '';
    this.takipte = takip;
    this.zamanlayicilariSil();
    if (takip) {
      this.dur('takip');
      this.tTakip = this.o.zaman.set(() => { this.tTakip = null; this.takipte = false; this.dur('bekle'); }, this.o.takipMs);
    } else {
      this.dur('bekle');
    }
    this.ac();
  }

  private kapat() {
    const r = this.rec;
    this.rec = null;
    if (!r) return;
    r.onresult = r.onerror = r.onend = null;
    try { r.abort(); } catch { /* zaten kapalı */ }
  }

  private ac() {
    if (!this.acik || this.durakli || this.rec) return;
    const r = this.o.fabrika();
    if (!r) { this.dur('hata'); this.o.onHata?.('Bu tarayıcıda ses tanıma yok.'); this.acik = false; return; }
    r.lang = 'tr-TR';
    r.continuous = true;
    r.interimResults = true;
    r.onresult = e => this.sonuc(e);
    r.onerror = e => this.hata(String(e?.error ?? ''));
    r.onend = () => {
      if (this.rec !== r) return;
      this.rec = null;
      this.yenidenDene();
    };
    this.rec = r;
    try { r.start(); } catch { /* zaten başlamış olabilir */ }
    this.temizle(this.tOturum);
    this.tOturum = this.o.zaman.set(() => {
      this.tOturum = null;
      // Komut alırken oturumu bölme; boştaysa yenile
      if (!this.dinliyor && this.rec === r) { this.kapat(); this.ac(); }
    }, this.o.oturumMs);
  }

  private yenidenDene() {
    if (!this.acik || this.durakli) return;
    const gecikme = this.ardisikHata >= 3 ? 1500 : 250;
    this.temizle(this.tYeniden);
    this.tYeniden = this.o.zaman.set(() => { this.tYeniden = null; this.ac(); }, gecikme);
  }

  private hata(kod: string) {
    if (kod === 'not-allowed' || kod === 'service-not-allowed') {
      this.acik = false;
      this.zamanlayicilariSil();
      this.kapat();
      this.dur('hata');
      this.o.onHata?.('Mikrofon izni verilmedi.');
      return;
    }
    if (kod === 'no-speech' || kod === 'aborted') return; // olağan: yeniden denenir
    this.ardisikHata++;
    this.o.onHata?.(`Dinleme hatası: ${kod}`);
  }

  private sonuc(e: any) {
    this.ardisikHata = 0;
    const liste = e?.results;
    if (!liste) return;
    let tum = '';
    for (let i = 0; i < liste.length; i++) tum += (i ? ' ' : '') + (liste[i]?.[0]?.transcript ?? '');
    tum = tum.trim();
    if (!tum) return;

    if (!this.dinliyor) {
      const r = jarvisAra(tum);
      if (r.bulundu) {
        this.dinliyor = true;
        this.temizle(this.tTakip);
        this.tTakip = null;
        this.dur('dinliyor');
        this.o.onUyandi();
        this.komut = r.komut;
        this.o.onGecici?.(r.komut);
        this.kurSessizlik(!!r.komut);
        return;
      }
      if (this.takipte) {
        // Takip penceresi: "Jarvis" demeden de komut kabul edilir
        this.dinliyor = true;
        this.temizle(this.tTakip);
        this.tTakip = null;
        this.dur('dinliyor');
        this.o.onUyandi();
        this.komut = tum;
        this.o.onGecici?.(tum);
        this.kurSessizlik(true);
      }
      return;
    }
    const r = jarvisAra(tum);
    this.komut = this.takipte ? (r.bulundu ? r.komut : tum) : r.bulundu ? r.komut : this.komut;
    this.o.onGecici?.(this.komut);
    this.kurSessizlik(!!this.komut);
  }

  /** Söz geldikçe yeniden kurulur: son sözden sonra sessizlikMs geçerse komut gider. Söz yoksa komutBeklemeMs. */
  private kurSessizlik(sozVar: boolean) {
    this.temizle(this.tSessiz, this.tBekle);
    this.tSessiz = this.tBekle = null;
    if (sozVar) {
      this.tSessiz = this.o.zaman.set(() => { this.tSessiz = null; this.bitir(); }, this.o.sessizlikMs);
    } else {
      this.tBekle = this.o.zaman.set(() => { this.tBekle = null; this.vazgec(); }, this.o.komutBeklemeMs);
    }
  }

  private bitir() {
    const komut = this.komut.trim();
    this.dinliyor = false;
    this.komut = '';
    this.takipte = false;
    this.zamanlayicilariSil();
    if (komut.length < 2) { this.kapat(); this.dur('bekle'); this.ac(); return; }
    this.durakli = true; // cevap gelene kadar dinleme durur; App devam() çağırır
    this.kapat();
    this.dur('durakladi');
    this.o.onMetin(komut);
  }

  private vazgec() {
    this.dinliyor = false;
    this.komut = '';
    this.takipte = false;
    this.zamanlayicilariSil();
    this.kapat();
    this.dur('bekle');
    this.ac();
  }
}

/** Tarayıcıda gerçek tanıyıcı üretir (yoksa null). */
export function tarayiciTanimasi(): TanimaBenzeri | null {
  const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
  return SR ? (new SR() as TanimaBenzeri) : null;
}
export const canliDestekleniyor = () => !!((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);
