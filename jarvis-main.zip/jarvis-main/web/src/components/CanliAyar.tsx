import { canliDestekleniyor, type CanliDurum } from '../lib/hotword';

const DURUM_AD: Record<CanliDurum, string> = {
  kapali: 'Kapalı',
  bekle: '“Jarvis” demeni bekliyor',
  dinliyor: 'Seni dinliyor',
  takip: 'Devam edebilirsin (“Jarvis” demeden)',
  durakladi: 'Cevap veriyor, bekliyor',
  hata: 'Çalışmıyor: mikrofon izni ya da tarayıcı desteği yok',
};

/** Ayarlar: tuşsuz canlı dinleme. Açıkken "Jarvis" deyince aktif olur. */
export function CanliAyar(p: { acik: boolean; durum: CanliDurum; onChange(v: boolean): void }) {
  const destek = canliDestekleniyor();
  return (
    <>
      <label>Canlı dinleme (tuşsuz)</label>
      <div className="seg">
        <button className={p.acik ? 'on' : ''} disabled={!destek} onClick={() => p.onChange(true)}>Açık</button>
        <button className={!p.acik ? 'on' : ''} onClick={() => p.onChange(false)}>Kapalı</button>
      </div>
      <p className="muted small">
        {destek ? `Durum: ${DURUM_AD[p.durum]}.` : 'Bu tarayıcıda ses tanıma yok; yazarak ya da mikrofon düğmesiyle konuş.'}
        {' '}Açıkken mikrofon sürekli dinler; konuşmalar tarayıcının ses tanıma servisine (Chrome: Google, Safari: Apple) gider. Cevaptan sonra birkaç saniye “Jarvis” demeden devam edebilirsin. iPhone’da ekran kapanınca ya da uygulama arka plana geçince durur.
      </p>
    </>
  );
}
