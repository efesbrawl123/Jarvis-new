import { useState } from 'react';
import '../temalar.css';
import { voice } from '../lib/speech';
import { KARAKTERLER, TEMALAR, loadKarakter, loadTema, saveKarakter, setTema, type SesKarakter } from '../lib/gorunum';

/** Ayarlar: renk teması (bu cihazda saklanır) */
export function TemaSecici() {
  const [secili, setSecili] = useState(loadTema());
  return (
    <>
      <label>Renk teması (bu cihazda)</label>
      <div className="seg tema-seg">
        {TEMALAR.map(t => (
          <button key={t.id} className={secili === t.id ? 'on' : ''} onClick={() => { setTema(t.id); setSecili(t.id); }}>
            <i className="tema-nokta" style={{ background: t.renk, color: t.renk }} />{t.ad}
          </button>
        ))}
      </div>
      <p className="muted small">Renkleri değiştirir, düzen aynı kalır. Çekirdek ve bazı efektler kendi renginde kalabilir.</p>
    </>
  );
}

function onizle(k: SesKarakter) {
  try {
    if (!('speechSynthesis' in window)) return;
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance('Merhaba, ben Jarvis. Dinliyorum.');
    u.lang = 'tr-TR';
    const vs = voice.browserVoices();
    const ad = voice.browserVoiceName;
    const v = (ad ? vs.find(x => x.name === ad) : undefined) || vs[0];
    if (v) u.voice = v;
    u.pitch = k.perde;
    u.rate = voice.rate * k.hiz;
    speechSynthesis.speak(u);
  } catch { /* yok say */ }
}

/** Ayarlar: tarayıcı sesinin karakteri (perde ve hız). Sunucu sesi seçiliyken etkisizdir. */
export function SesKarakteri() {
  const [secili, setSecili] = useState(loadKarakter().id);
  return (
    <>
      <label>Ses karakteri (tarayıcı sesi)</label>
      <div className="seg tema-seg">
        {KARAKTERLER.map(k => (
          <button key={k.id} className={secili === k.id ? 'on' : ''} title={k.alt} onClick={() => { saveKarakter(k.id); setSecili(k.id); onizle(k); }}>
            {k.ad}
          </button>
        ))}
      </div>
      <p className="muted small">Seçince kısa bir örnek duyarsın. Perde ve hızı değiştirir; ses adını aşağıdaki listeden seçersin.</p>
    </>
  );
}
