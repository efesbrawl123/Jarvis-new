// El Kontrolü: kamera görüntüsü üstünde el takibi, büyü efektleri ve jestle Jarvis kontrolü.
// Tuşlar: Esc kapat · L arayüzü gizle/göster (temiz çekim) · D iskelet · M ses · C kamera değiştir · F yüz kilidi · K kitaplık ayarı
import type { HandLandmarker } from '@mediapipe/tasks-vision';
import { useEffect, useRef, useState } from 'react';
import { Controller, KONTROLLER, type Kontrol, type Status } from './controller';
import { Fx } from './fx';
import { GESTURE_LABEL } from './gestures';
import { Sfx } from './sfx';
import { demoBookHands, demoHands } from './synthetic';
import { detect, listCameras, loadLandmarker, openCamera, type CameraInfo, type RawHand } from './tracker';
import { FaceHud, demoFace, detectFaces, loadFaceDetector } from './face';
import type { FaceDetector } from '@mediapipe/tasks-vision';
import { Library, loadCover, thumbOf } from './library';
import LibraryEditor from './LibraryEditor';
import { DEMO_TARGET, buildDemoShelf, demoStream } from './shelfDemo';
import { AYAR_LISTESI, loadAyar, saveAyar, type ElAyar } from './settings';
import { PROFILLER, PROFIL_AD, loadProfil, perfState, profilCoz, saveProfil, type Profil } from './perf';
import { GEZEGENLER, type GezegenTur } from './fx';
import { fillBook, getLibrary, saveLibrary, scanLibrary, shelfRegion, tileFrame, type Kitap } from '../lib/library';
import { cizEvren, yeniDurum } from '../evren/ciz';
import { EVREN_EL_OZELLIKLER, evrenOzellikUygula } from './evrenFeatures';
import './hands.css';

export interface HandControlProps {
  /** Sentetik ellerle çalış (kamera yok): ?el=demo */
  demo?: boolean;
  /** Jarvis'in o anki altyazısı ve durumu */
  caption: string;
  core: string;
  onAction(k: Kontrol): void;
  onClose(): void;
  /** Yüz HUD etiketindeki ad (.env USER_NAME) */
  userName?: string;
  /** Kullanıcının yüzüne kilitlendi (yalnızca "TANINDI" yüz için) */
  onFaceLock?(): void;
  /** Demo: arka plana prosedürel kitaplık (?el=demo&kitaplik=1) */
  kitaplik?: boolean;
  /** Sunucuda kitaplık değişti (SSE): haritayı yeniden yükle */
  libraryKey?: number;
  /** "Jarvis, kitaplığımı tara": her artışta bir tarama */
  scanSignal?: number;
  onScanDone?(r: { bulunan: number; belirsiz: number; hata?: string }): void;
  /** Kitap açıkken 👍 basılı: özeti seçili sesle oku */
  onBookRead?(k: Kitap): void;
  /** Açık kitap değişti ("Jarvis, bunu özetle" için) */
  onBookOpen?(k: Kitap | null): void;
  /** "Jarvis, Mars yap": n her istekte artar */
  planetCmd?: { tur: GezegenTur; n: number } | null;
}

const LEGEND: [string, string][] = [
  ['✋', 'ateş'], ['✋✋', 'mühür'], ['🤏', 'gezegen'], ['🤏🤏', 'büyüt'], ['✊→✋', 'patlat'], ['☝️☝️', 'şimşek'], ['☝️', 'iz'],
  ...KONTROLLER.map(k => [k.jest === 'basparmak' ? '👍' : k.jest === 'zafer' ? '✌️' : k.jest === 'yumruk' ? '✊ tut' : k.jest === 'boynuz' ? '🤘' : k.jest === 'telefon' ? '🤙' : k.jest === 'uc' ? '🖖' : k.jest, k.ad.replace(/^\S+\s/, '').toLocaleLowerCase('tr')] as [string, string]),
];

/** Kitap dışarıdayken (seçili/tutuldu/açık) jest listesi */
const LEGEND_KITAP: [string, string][] = [['☝️', 'kitap seç'], ['🤏', 'tut ve çek'], ['✋⇠', 'sayfa çevir'], ['👍', 'özeti oku'], ['✊', 'rafa koy'], ['✋⤴', 'ileri it: rafa koy']];

export default function HandControl(p: HandControlProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const evrenCanvasRef = useRef<HTMLCanvasElement>(null);
  const evrenStateRef = useRef(yeniDurum());
  const evrenAcikRef = useRef(false);
  const elOncekiRef = useRef<{ x: number; y: number; mesafe: number; pinchY: number } | null>(null);
  const evrenJestRef = useRef('');
  const [evrenAcik, setEvrenAcik] = useState(false);
  const [evrenDuraklat, setEvrenDuraklat] = useState(false);
  const [evrenOzellikAcik, setEvrenOzellikAcik] = useState(false);
  const [issDurum, setIssDurum] = useState<'yükleniyor' | 'canlı' | 'simülasyon'>('simülasyon');
  const issDurumRef = useRef<'yükleniyor' | 'canlı' | 'simülasyon'>('simülasyon');
  const evrenDuraklatRef = useRef(false);
  useEffect(() => { evrenDuraklatRef.current = evrenDuraklat; }, [evrenDuraklat]);
  useEffect(() => { issDurumRef.current = issDurum; }, [issDurum]);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const faceRef = useRef<HTMLCanvasElement>(null);
  const shelfRef = useRef<HTMLCanvasElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const libRef = useRef<Library | null>(null);
  const shelfDemo = !!(p.demo && p.kitaplik);
  useEffect(() => { evrenAcikRef.current = evrenAcik; if (!evrenAcik) elOncekiRef.current = null; }, [evrenAcik]);
  /** Kitaplık ayar modu (K) */
  const [editing, setEditing] = useState(false);
  // Kitaplık demosu: prosedürel raf ve kitapları bir kez üret
  const [demoShelf] = useState(() => (shelfDemo ? buildDemoShelf() : null));
  const [libBooks, setLibBooks] = useState<Kitap[]>(() => demoShelf?.books ?? []);
  const [scanning, setScanning] = useState(false);
  const [moved, setMoved] = useState(false);
  const [dims, setDims] = useState({ W: window.innerWidth, H: window.innerHeight, vw: 1920, vh: 1080 });
  /** Efekt ayarları (⚙ / E): bu cihazda saklanır. Kitaplık demosunda yüz kilidi kapalı başlar (raf temiz görünsün). */
  const [ayar, setAyarState] = useState<ElAyar>(() => ({ ...loadAyar(), ...(shelfDemo ? { yuz: false } : {}) }));
  const [ayarOpen, setAyarOpen] = useState(false);
  const [profil, setProfilState] = useState<Profil>(() => loadProfil());
  const setAyar = (patch: Partial<ElAyar>) => setAyarState(a => { const n = { ...a, ...patch }; if (!shelfDemo) saveAyar(n); return n; });
  const face = ayar.yuz;
  const faceOn = useRef(face);
  const ayarRef = useRef(ayar);
  useEffect(() => { faceOn.current = face; ayarRef.current = ayar; }, [face, ayar]);
  const [status, setStatus] = useState<string>('kamera açılıyor…');
  const [err, setErr] = useState<string | null>(null);
  const [hud, setHud] = useState(true);
  const [stats, setStats] = useState<{ fps: number; st: Status; delegate: string; step?: string }>({ fps: 0, st: { hands: [], mode: '—' }, delegate: '' });
  const muted = !ayar.ses;
  const [cams, setCams] = useState<CameraInfo[]>([]);
  const [camId, setCamId] = useState<string | undefined>(() => { try { return localStorage.getItem('jarvis.el.kamera') || undefined; } catch { return undefined; } });
  const [toast, setToast] = useState<string | null>(null);
  const ctlRef = useRef<Controller | null>(null);
  const actionRef = useRef(p.onAction);
  const closeRef = useRef(p.onClose);
  const faceLockRef = useRef(p.onFaceLock);
  const propsRef = useRef(p);
  useEffect(() => { actionRef.current = p.onAction; closeRef.current = p.onClose; faceLockRef.current = p.onFaceLock; propsRef.current = p; });
  // Ses bağlamı: açılış bir tık/tuşla olduğundan kullanıcı hareketi hâlâ geçerli
  const [sfx] = useState(() => new Sfx());
  useEffect(() => { sfx.unlock(); return () => sfx.stop(); }, [sfx]);
  const nextCam = () => {
    if (!cams.length) return;
    const i = cams.findIndex(c => c.deviceId === camId);
    const n = cams[(i + 1) % cams.length];
    try { localStorage.setItem('jarvis.el.kamera', n.deviceId); } catch { /* yok say */ }
    setCamId(n.deviceId);
  };

  // Kamera + model + döngü
  useEffect(() => {
    const canvas = canvasRef.current!, video = videoRef.current!;
    // Performans profili: kamera çözünürlüğü, algılama sıklığı, efekt yükü (iPhone'da donmayı önler)
    const cfg = { ...PROFILLER[profilCoz(profil)] };
    perfState.dprCap = cfg.dprTavan;
    const fx = new Fx(canvas);
    fx.MAX = cfg.parcacik;
    const ctl = new Controller(fx, sfx);
    ctlRef.current = ctl;
    if (p.demo) ctl.debug = true; // kamera yok: sentetik eller iskelet olarak görünsün
    ctl.onAction = k => {
      setToast(p.demo ? `demo · ${k.ad} (komut gönderilmedi)` : k.ad);
      setTimeout(() => setToast(null), 2200);
      if (!p.demo) actionRef.current(k);
    };
    const hudFace = new FaceHud(faceRef.current!, p.userName || '');
    hudFace.onLock = () => { sfx.lockOn(); faceLockRef.current?.(); };
    const lib = new Library(shelfRef.current!, stageRef.current!, video, fx, sfx, {
      onRead: k => {
        if (p.demo) { setToast('demo · Jarvis özeti seçili sesle okurdu'); setTimeout(() => setToast(null), 2200); return; }
        propsRef.current.onBookRead?.(k);
      },
      onOpenChange: k => propsRef.current.onBookOpen?.(k),
      fill: k => (k.id.startsWith('demo-') ? Promise.resolve(null) : fillBook(k.id).then(r => r.kitap).catch(() => null)),
      cover: loadCover,
    });
    libRef.current = lib;
    ctl.library = lib;
    const size = () => {
      const W = window.innerWidth, H = window.innerHeight;
      fx.resize(W, H); hudFace.resize(W, H); lib.resize(W, H);
      const ec = evrenCanvasRef.current; if (ec) { const dpr = Math.min(window.devicePixelRatio || 1, 2); ec.width = Math.round(W * dpr); ec.height = Math.round(H * dpr); ec.style.width = `${W}px`; ec.style.height = `${H}px`; }
      setDims({ W, H, vw: video.videoWidth || 1920, vh: video.videoHeight || 1080 });
    };
    size();
    window.addEventListener('resize', size);

    let alive = true, raf = 0, stream: MediaStream | null = null, lm: HandLandmarker | null = null, fd: FaceDetector | null = null, faceTick = 0;
    let last = performance.now(), lastVideoT = -1, frames = 0, fpsAt = last, hands: RawHand[] = [], delegate = '';
    let lastDetectAt = 0, lowCount = 0, degraded = false;
    const startedAt = last;
    const demoStart = performance.now() - (Number(new URLSearchParams(location.search).get('elt')) || 0) * 1000;
    let step = '';
    // Kitaplık demosu: prosedürel raf sahte kamera akışı olarak <video>'ya; tarama sahnesi her döngü başında
    let demoCam: ReturnType<typeof demoStream> | null = null;
    const demoBooks: Kitap[] = demoShelf?.books ?? [];
    const demoTarget = demoBooks.find(b => b.ad === DEMO_TARGET)?.id ?? '';
    let demoLoop = -1;
    if (demoShelf) {
      demoCam = demoStream(demoShelf.frame);
      video.srcObject = demoCam.stream;
      video.muted = true;
      video.play().catch(() => {});
      video.addEventListener('loadedmetadata', size, { once: true });
      lib.setBooks(demoBooks, { genislik: demoShelf.frame.width, yukseklik: demoShelf.frame.height, kucukResim: thumbOf(demoShelf.frame) });
      demoJiggle.current = demoCam.jiggle;
    }
    let lastMoved = false, libOn = true;

    const loop = () => {
      if (!alive) return;
      raf = requestAnimationFrame(loop);
      const now = performance.now();
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      if (demoShelf) {
        const t = (now - demoStart) / 1000;
        const d = demoBookHands(t, fx.W, fx.H, lib.rectOf(demoTarget));
        if (d.loop !== demoLoop) {
          demoLoop = d.loop;
          lib.scanStart();
          setTimeout(() => { if (alive) lib.scanResult(demoBooks, demoBooks.filter(b => b.ad).length, demoBooks.filter(b => !b.ad).length); }, 1300);
        }
        hands = d.hands; step = d.step;
      } else if (p.demo) {
        const d = demoHands((now - demoStart) / 1000, fx.W, fx.H);
        hands = d.hands; step = d.step;
      } else if (lm && video.readyState >= 2 && video.currentTime !== lastVideoT && now - lastDetectAt >= cfg.algilaMs) {
        lastVideoT = video.currentTime;
        lastDetectAt = now;
        try { hands = detect(lm, video, now, fx.W, fx.H); } catch (e) { console.warn('[el] algılama', e); }
      }
      // Yüz: demoda sahte yüz; kamerada her 3. yeni karede algıla (el takibine yer kalsın), arada yumuşatılmış kutu
      if (faceOn.current) {
        if (p.demo) hudFace.update(demoFace((now - demoStart) / 1000, fx.W, fx.H), now);
        else if (fd && cfg.yuzHer > 0 && video.readyState >= 2 && ++faceTick % cfg.yuzHer === 0) {
          try { hudFace.update(detectFaces(fd, video, now, fx.W, fx.H), now); } catch (e) { console.warn('[el] yüz', e); }
        }
        hudFace.render(now);
      } else hudFace.clear();
      ctl.ayar = ayarRef.current;
      const st = ctl.update(hands, now, dt);
      // EVREN MODU: MediaPipe el noktaları doğrudan Dünya kamerasını ve uydu görünümünü yönetir.
      if (evrenAcikRef.current) {
        const S = evrenStateRef.current;
        const liveHands = [...ctl.hands.values()].filter(h => now - h.lastSeen < 180);
        const ec = evrenCanvasRef.current;
        if (ec) {
          const ctx = ec.getContext('2d');
          if (ctx) {
            const dpr = Math.min(window.devicePixelRatio || 1, 2);
            ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
            if (!evrenDuraklatRef.current) S.simSn += dt * 30;
            if (liveHands.length >= 2) {
              const a = liveHands[0].shape.palm, b = liveHands[1].shape.palm;
              const mesafe = Math.hypot(a.x - b.x, a.y - b.y);
              const prev = elOncekiRef.current;
              if (prev) S.d = Math.max(1.35, Math.min(8, S.d + (prev.mesafe - mesafe) * 0.006));
              elOncekiRef.current = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, mesafe, pinchY: 0 };
              S.lon0 += ((a.x + b.x) / 2 - (prev?.x ?? (a.x + b.x) / 2)) * 0.004;
              S.lat0 = Math.max(-1.35, Math.min(1.35, S.lat0 - ((a.y + b.y) / 2 - (prev?.y ?? (a.y + b.y) / 2)) * 0.003));
            } else if (liveHands.length === 1) {
              const h = liveHands[0], palm = h.shape.palm;
              const prev = elOncekiRef.current;
              if (h.gesture === 'acik' || h.gesture === 'isaret') {
                if (prev) {
                  S.lon0 -= (palm.x - prev.x) * 0.006;
                  S.lat0 = Math.max(-1.35, Math.min(1.35, S.lat0 + (palm.y - prev.y) * 0.004));
                }
                elOncekiRef.current = { x: palm.x, y: palm.y, mesafe: 0, pinchY: palm.y };
              } else if (h.gesture === 'cimdik') {
                if (prev) S.d = Math.max(1.35, Math.min(8, S.d + (palm.y - prev.pinchY) * 0.018));
                elOncekiRef.current = { x: palm.x, y: palm.y, mesafe: 0, pinchY: palm.y };
              } else if (h.gesture === 'yumruk') {
                elOncekiRef.current = null;
              } else if (prev && h.gesture === 'diger') {
                elOncekiRef.current = { x: palm.x, y: palm.y, mesafe: 0, pinchY: palm.y };
              }
            } else elOncekiRef.current = null;
            const activeGesture = liveHands.length === 1 ? liveHands[0].gesture : '';
            if (activeGesture !== evrenJestRef.current) {
              if (activeGesture === 'zafer') S.uydular = !S.uydular;
              if (activeGesture === 'uc') S.mod = S.mod === 'dunya' ? 'gunes' : S.mod === 'gunes' ? 'gezegen' : 'dunya';
              if (activeGesture === 'basparmak') { S.lon0 = 29 * Math.PI / 180; S.lat0 = 28 * Math.PI / 180; S.d = 3.3; }
              if (activeGesture === 'yumruk') setEvrenDuraklat(true);
              if (activeGesture === 'acik') setEvrenDuraklat(false);
              if (activeGesture === 'isaret' && S.iss) { S.lon0 = S.iss.lon; S.lat0 = S.iss.lat; }
              if (activeGesture === 'boynuz') S.uydular = !S.uydular;
              if (activeGesture === 'telefon') { S.rgb = S.rgb === '77, 225, 255' ? '80, 255, 190' : '77, 225, 255'; }
              evrenJestRef.current = activeGesture;
            }
            S.iss = S.iss ?? null;
            cizEvren(ctx, S, window.innerWidth, window.innerHeight, Date.now());
            // Alt bilgi ve kontrol ipuçları
            ctx.save(); ctx.fillStyle = 'rgba(4,18,30,.78)'; ctx.strokeStyle = 'rgba(70,220,255,.55)'; ctx.lineWidth = 1;
            ctx.fillRect(18, dims.H - 82, 310, 60); ctx.strokeRect(18, dims.H - 82, 310, 60);
            ctx.fillStyle = '#8ceeff'; ctx.font = '600 12px system-ui'; ctx.fillText(`J.A.R.V.I.S. · EVREN / ${issDurumRef.current === 'canlı' ? 'ISS CANLI' : 'UYDU SİMÜLASYONU'}`, 30, dims.H - 60);
            ctx.fillStyle = '#e9fbff'; ctx.font = '11px system-ui'; ctx.fillText('✋ Döndür  ·  🤏 Yakınlaştır  ·  ✊ Duraklat', 30, dims.H - 38);
            ctx.restore();
          }
        }
      }
      // Kitaplık ayardan kapatılınca dışarıdaki kitap ve raf katmanı temizlenir
      if (ctl.ayar.kitaplik) { libOn = true; lib.render(now); }
      else if (libOn) { libOn = false; lib.reset(); }
      if (lib.moved !== lastMoved) { lastMoved = lib.moved; setMoved(lib.moved); }
      frames++;
      if (now - fpsAt > 400) {
        const fps = Math.round((frames * 1000) / (now - fpsAt));
        frames = 0; fpsAt = now;
        // Yavaşlama koruması: kare hızı ısrarla düşükse (≈2 sn) el algılamayı seyrelt, yüzü kapat, efekti hafiflet
        if (!degraded && !p.demo && now - startedAt > 5000) {
          lowCount = fps < 20 ? lowCount + 1 : 0;
          if (lowCount >= 5) {
            degraded = true;
            cfg.algilaMs = Math.max(cfg.algilaMs, 50);
            cfg.yuzHer = 0;
            fx.MAX = Math.min(fx.MAX, 1800);
            perfState.dprCap = 1;
            size();
            hudFace.clear();
            setToast('Performans: hafif efekt moduna geçildi');
            setTimeout(() => setToast(null), 2600);
          }
        }
        setStats({ fps, st, delegate, step });
      }
    };

    (async () => {
      if (p.demo) { setStatus(''); loop(); return; }
      try {
        const s = await openCamera(video, camId, { genislik: cfg.genislik, yukseklik: cfg.yukseklik, fps: cfg.fps });
        // Bu başlatma bu arada geçersiz kaldıysa (bileşen yeniden başladı / kapandı) kamerayı hemen kapat
        if (!alive) { s.getTracks().forEach(t => t.stop()); return; }
        stream = s;
        listCameras().then(setCams);
        size();
        // Kitaplık haritası (kurulumda bir kez taranır; sunucuda durur)
        getLibrary().then(k => { if (!alive) return; lib.setBooks(k.kitaplar, k.referans); setLibBooks(k.kitaplar); }).catch(() => {});
      } catch (e: any) {
        if (!alive) return; // eski başlatmanın hatası ekrana gelmesin
        setErr(e?.name === 'NotAllowedError' ? 'Kamera izni verilmedi. Adres çubuğundaki kamera simgesinden izin verin.' : `Kamera açılamadı: ${e?.message || e}`);
        return;
      }
      try {
        const r = await loadLandmarker(setStatus);
        if (!alive) { r.lm.close(); return; }
        lm = r.lm; delegate = r.delegate;
        setStatus('');
        // Yüz algılayıcı: yüklenemezse el kontrolü yine çalışır (yalnızca yüz HUD'u olmaz)
        if (cfg.yuzHer > 0) loadFaceDetector().then(d => { if (alive) fd = d; else d.close(); }).catch(e => console.warn('[el] yüz algılayıcı yüklenemedi', e)); // hafif profilde yüz modeli hiç yüklenmez (bellek ve işlemci)
      } catch (e: any) {
        setErr(`El takip modeli yüklenemedi: ${e?.message || e}. İnternet bağlantısını kontrol edin ya da "npm run el-modeli" ile modeli indirin.`);
        return;
      }
      loop();
    })();

    return () => {
      alive = false;
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', size);
      stream?.getTracks().forEach(t => t.stop());
      lm?.close();
      fd?.close();
      sfx.setRoar(0);
      demoCam?.stop();
      lib.dispose();
      libRef.current = null;
    };
  }, [p.demo, camId, sfx, demoShelf, profil]);

  // ---- Kitaplık: tarama, harita yenileme, ayar modu
  /** Kameradan TAM ÇÖZÜNÜRLÜKTE tek kare (aynalanmamış) → görüntü modeli → kutular. Demoda sahte sonuç. */
  const scanBusy = useRef(false);
  /** Kitaplık demosu: J tuşu kamerayı "kıpırdatır" (uyarıyı denemek için) */
  const demoJiggle = useRef<((on: boolean) => void) | null>(null);
  const jiggled = useRef(false);
  const runScan = async () => {
    const lib = libRef.current, video = videoRef.current;
    if (!lib || !video || scanBusy.current) return;
    scanBusy.current = true;
    setScanning(true);
    lib.scanStart();
    const done = (r: { bulunan: number; belirsiz: number; hata?: string }) => { scanBusy.current = false; setScanning(false); propsRef.current.onScanDone?.(r); };
    if (shelfDemo) {
      setTimeout(() => {
        const books = lib.books;
        lib.scanResult(books, books.filter(b => b.ad).length, books.filter(b => !b.ad).length);
        done({ bulunan: books.filter(b => b.ad).length, belirsiz: books.filter(b => !b.ad).length });
      }, 1300);
      return;
    }
    // Kamera hazır değilse biraz bekle (sesli komutla El Kontrolü yeni açıldıysa)
    for (let i = 0; i < 40 && (video.readyState < 2 || !video.videoWidth); i++) await new Promise(r => setTimeout(r, 250));
    if (!video.videoWidth) { lib.scanFail('kamera hazır değil'); done({ bulunan: 0, belirsiz: 0, hata: 'kamera hazır değil' }); return; }
    try {
      const c = document.createElement('canvas');
      c.width = video.videoWidth; c.height = video.videoHeight;
      c.getContext('2d')!.drawImage(video, 0, 0);
      // İlk taramada tüm kare; sonra yalnızca rafın bulunduğu bölge (kamera kıpırdadıysa yine tüm kare)
      const region = lib.moved ? undefined : shelfRegion(lib.books);
      const r = await scanLibrary({ parcalar: tileFrame(c, region), genislik: c.width, yukseklik: c.height, kucukResim: thumbOf(video) });
      lib.setBooks(r.kitaplik.kitaplar, r.kitaplik.referans);
      setLibBooks(r.kitaplik.kitaplar);
      if (r.hata) lib.scanFail(r.hata);
      else lib.scanResult(r.kitaplik.kitaplar.filter(b => b.kutu), r.bulunan, r.belirsiz);
      done({ bulunan: r.bulunan, belirsiz: r.belirsiz, hata: r.hata });
    } catch (e) {
      const msg = (e as Error).message;
      lib.scanFail(msg);
      done({ bulunan: 0, belirsiz: 0, hata: msg });
    }
  };
  // "Jarvis, kitaplığımı tara"
  const lastSignal = useRef(p.scanSignal ?? 0);
  useEffect(() => {
    if (!p.scanSignal || p.scanSignal === lastSignal.current) return;
    lastSignal.current = p.scanSignal;
    runScan();
  }, [p.scanSignal]); // eslint-disable-line react-hooks/exhaustive-deps
  // "Jarvis, Mars yap": eldeki gezegen dönüşür, yoksa sonraki çimdikte gelir
  const lastPlanetCmd = useRef(p.planetCmd?.n ?? 0);
  useEffect(() => {
    const c = p.planetCmd;
    if (!c || c.n === lastPlanetCmd.current || !ctlRef.current) return;
    lastPlanetCmd.current = c.n;
    const ad = GEZEGENLER.find(g => g.tur === c.tur)!.ad.toLocaleUpperCase('tr');
    const morphed = ctlRef.current.setPlanet(c.tur, performance.now());
    if (!morphed) { setToast(`◉ ${ad} · çimdikle oluştur`); setTimeout(() => setToast(null), 2200); }
  }, [p.planetCmd]);

  // Sunucuda kitaplık değişti (not eklendi, Ayarlar'dan düzenlendi): haritayı yenile
  useEffect(() => {
    if (!p.libraryKey || shelfDemo) return;
    getLibrary().then(k => { libRef.current?.setBooks(k.kitaplar, k.referans); setLibBooks(k.kitaplar); }).catch(() => {});
  }, [p.libraryKey, shelfDemo]);
  useEffect(() => { if (libRef.current) libRef.current.paused = editing; }, [editing]);
  // ISS'nin gerçek enlem/boylamı; ağ veya servis yoksa simülasyon etiketi korunur.
  useEffect(() => {
    if (!evrenAcik) return;
    let alive = true;
    const pull = async () => {
      try {
        const r = await fetch('https://api.wheretheiss.at/v1/satellites/25544', { cache: 'no-store' });
        if (!r.ok) throw new Error('ISS servisi yanıt vermedi');
        const d = await r.json() as { latitude: number; longitude: number };
        if (!alive || !Number.isFinite(d.latitude) || !Number.isFinite(d.longitude)) return;
        evrenStateRef.current.iss = { lon: d.longitude * Math.PI / 180, lat: d.latitude * Math.PI / 180 };
        setIssDurum('canlı');
      } catch { if (alive) setIssDurum('simülasyon'); }
    };
    setIssDurum('yükleniyor'); pull();
    const id = window.setInterval(pull, 5000);
    return () => { alive = false; window.clearInterval(id); };
  }, [evrenAcik]);

  const saveBooks = async (list: Kitap[]) => {
    const lib = libRef.current;
    if (shelfDemo) { lib?.setBooks(list, null); setLibBooks(list); setToast('demo · kaydedilmedi'); setTimeout(() => setToast(null), 1800); return; }
    try {
      const k = await saveLibrary({ kitaplar: list });
      lib?.setBooks(k.kitaplar, k.referans);
      setLibBooks(k.kitaplar);
      setToast(`kitaplık kaydedildi · ${k.kitaplar.filter(b => b.ad).length} kitap`);
    } catch (e) {
      setToast(`kaydedilemedi: ${(e as Error).message}`);
    }
    setTimeout(() => setToast(null), 2200);
  };

  // Tuşlar
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      // Kitaplık ayar modunda ad yazarken tuşlar kısayol sayılmaz
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement || e.target instanceof HTMLSelectElement) return;
      if (e.key === 'Escape') { e.stopPropagation(); if (editing) setEditing(false); else closeRef.current(); return; }
      if (e.code === 'KeyL') setHud(h => !h);
      else if (e.code === 'KeyD' && ctlRef.current) ctlRef.current.debug = !ctlRef.current.debug;
      else if (e.code === 'KeyM') setAyar({ ses: !ayarRef.current.ses });
      else if (e.code === 'KeyF') setAyar({ yuz: !ayarRef.current.yuz });
      else if (e.code === 'KeyE') setAyarOpen(v => !v);
      else if (e.code === 'KeyK') setEditing(v => !v);
      else if (e.code === 'KeyJ' && demoJiggle.current) { jiggled.current = !jiggled.current; demoJiggle.current(jiggled.current); }
      else if (e.code === 'KeyC' && cams.length > 1) nextCam();
      else return;
      e.stopPropagation();
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  });

  useEffect(() => sfx.setOn(!muted), [muted, sfx]);

  const st = stats.st;
  return (
    <div className={'el-root' + (p.demo ? ' demo' : '') + (shelfDemo ? ' shelf' : '')}>
      <video ref={videoRef} className={'el-video' + (evrenAcik ? ' evren-hidden-video' : '')} playsInline muted />
      <canvas ref={evrenCanvasRef} className={'el-evren-canvas' + (evrenAcik ? ' on' : '')} />
      <canvas ref={shelfRef} className="el-shelf" />
      <canvas ref={canvasRef} className="el-canvas" />
      <div ref={stageRef} className="lb-stage" />
      <canvas ref={faceRef} className="el-face" />
      {evrenAcik && <div className="el-evren-controls"><b>EVREN KONTROLÜ</b><span>ISS: {issDurum === 'canlı' ? 'GERÇEK ZAMANLI' : 'SİMÜLASYON'}</span><button className="el-btn" onClick={() => { evrenStateRef.current.mod = 'dunya'; }}>Dünya</button><button className="el-btn" onClick={() => { evrenStateRef.current.mod = 'gunes'; }}>Güneş sistemi</button><button className="el-btn" onClick={() => { evrenStateRef.current.uydular = !evrenStateRef.current.uydular; }}>Uydular aç/kapat</button><button className="el-btn" onClick={() => { evrenStateRef.current.d = Math.max(1.35, evrenStateRef.current.d - .35); }}>＋ Yakınlaş</button><button className="el-btn" onClick={() => { evrenStateRef.current.d = Math.min(8, evrenStateRef.current.d + .35); }}>－ Uzaklaş</button><button className="el-btn" onClick={() => setEvrenDuraklat(v => !v)}>{evrenDuraklat ? '▶ Devam' : 'Ⅱ Duraklat'}</button><button className="el-btn" onClick={() => { evrenStateRef.current.lon0 = 29 * Math.PI / 180; evrenStateRef.current.lat0 = 28 * Math.PI / 180; evrenStateRef.current.d = 3.3; }}>Sıfırla</button><button className="el-btn on" onClick={() => setEvrenOzellikAcik(v => !v)}>✋ 50 EL ÖZELLİĞİ</button></div>}
      {evrenAcik && evrenOzellikAcik && <aside className="el-evren-feature-panel"><header><b>J.A.R.V.I.S. · 50 EL KONTROL ÖZELLİĞİ</b><button className="el-btn" onClick={() => setEvrenOzellikAcik(false)}>✕</button></header><p>Özellik seçildiğinde Evren simülasyonuna uygulanır. El jestleriyle temel gezinti devam eder.</p><div className="el-evren-feature-grid">{EVREN_EL_OZELLIKLER.slice(0,50).map(item => <button key={item.id} className="el-evren-feature" title={item.aciklama} onClick={() => { evrenOzellikUygula(evrenStateRef.current,item.id); setToast(`${item.id}. ${item.ad}`); setTimeout(() => setToast(null),1800); }}>{String(item.id).padStart(2,'0')} · {item.ad}</button>)}</div></aside>}

      {hud && (
        <>
          <i className="el-corner tl" /><i className="el-corner tr" /><i className="el-corner bl" /><i className="el-corner br" />
          <div className="el-top">
            <span className="el-title">JARVIS · EL KONTROLÜ</span>
            <span className="el-chip">MOD: {st.mode.toLocaleUpperCase('tr')}</span>
            <span className="el-meta">{stats.fps} FPS · {st.hands.length} el{stats.delegate ? ` · ${stats.delegate}` : ''}{p.demo ? ' · DEMO' : ` · ${PROFIL_AD[profilCoz(profil)]}`}</span>
            {st.hands.map(h => <span key={h.id} className="el-meta">{GESTURE_LABEL[h.gesture]}</span>)}
            <span className="el-sp" />
            <button className={'el-btn' + (evrenAcik ? ' on' : '')} onClick={() => setEvrenAcik(v => !v)}>{evrenAcik ? '◉ EVRENİ KAPAT' : '◎ EVREN MODU'}</button>
            {cams.length > 1 && <button className="el-btn" onClick={nextCam} title="Kamera değiştir (C)">⟳ kamera</button>}
            <button className="el-btn" onClick={() => setAyar({ ses: !ayar.ses })} title="Efekt sesi (M)">{muted ? '🔇' : '🔊'}</button>
            <button className={'el-btn' + (ayarOpen ? ' on' : '')} onClick={() => setAyarOpen(v => !v)} title="Efektleri aç/kapat (E)">⚙ efektler</button>
            <button className="el-btn" onClick={p.onClose} title="Kapat (Esc)">✕</button>
          </div>
          <div className="el-legend">
            {(evrenAcik ? [['✋', 'Dünya döndür / devam'], ['🤏', 'yakınlaştır'], ['✋✋', 'iki elle zoom'], ['✌️', 'uyduları aç/kapat'], ['🖖', 'görünüm değiştir'], ['☝️', 'ISS konumuna odaklan'], ['✊', 'duraklat']] as [string, string][] : st.mode.startsWith('kitap') ? LEGEND_KITAP : LEGEND).map(([g, t]) => <span key={g + t}><b>{g}</b> {t}</span>)}
            <span className="el-keys">L arayüz · E efektler · F yüz kilidi · K kitaplık · D iskelet · M ses · Esc çık</span>
          </div>
          {p.demo && stats.step && <div className="el-step">{stats.step}</div>}
        </>
      )}

      {(p.caption || p.core === 'thinking') && (
        <div className={'el-caption ' + p.core}>
          <span className="el-dot" />
          {p.caption || 'düşünüyor…'}
        </div>
      )}
      {toast && <div className="el-toast">{toast}</div>}
      {ayarOpen && (
        <aside className="el-ayar" onPointerDown={e => e.stopPropagation()}>
          <header><b>EFEKTLER</b><button className="el-btn" onClick={() => setAyarOpen(false)}>✕</button></header>
          {AYAR_LISTESI.map(({ k, ad, alt }) => (
            <label key={k} className={ayar[k] ? 'on' : ''}>
              <input type="checkbox" checked={ayar[k]} onChange={e => setAyar({ [k]: e.target.checked })} />
              <span>{ad}</span>
              {alt && <em>{alt}</em>}
            </label>
          ))}
          <div className="el-ayar-row">
            <span>🪐 Gezegen</span>
            <select value={ayar.gezegenTur} onChange={e => setAyar({ gezegenTur: e.target.value as ElAyar['gezegenTur'] })}>
              <option value="sirayla">Sırayla (her çimdikte sonraki)</option>
              {GEZEGENLER.map(g => <option key={g.tur} value={g.tur}>{g.ad}</option>)}
            </select>
          </div>
          <div className="el-ayar-row">
            <span>⚡ Performans</span>
            <select value={profil} onChange={e => { const v = e.target.value as Profil; saveProfil(v); setProfilState(v); }}>
              <option value="otomatik">Otomatik ({PROFIL_AD[profilCoz('otomatik')]})</option>
              <option value="hafif">Hafif (en akıcı)</option>
              <option value="dengeli">Dengeli</option>
              <option value="yuksek">Yüksek (en net; kitaplık taraması için)</option>
            </select>
          </div>
          <p>Bu cihazda saklanır. Kapalı efekt hiç tetiklenmez. Sesle: "Jarvis, Mars yap". Kısayol: <b>E</b></p>
        </aside>
      )}
      {moved && !editing && <div className="el-warn">⚠ KAMERA KIPIRDAMIŞ · KİTAPLIĞI YENİDEN TARA (K)</div>}
      {editing && (
        <LibraryEditor
          books={libBooks} W={dims.W} H={dims.H} vw={dims.vw} vh={dims.vh}
          scanning={scanning} moved={moved} demo={shelfDemo}
          onScan={runScan} onSave={saveBooks} onClose={() => setEditing(false)}
        />
      )}
      {(status || err) && (
        <div className="el-status">
          {err ? <><b>El kontrolü başlatılamadı</b><span>{err}</span><button className="el-btn" onClick={p.onClose}>Kapat</button></> : <><span className="el-spin" />{status}</>}
        </div>
      )}
    </div>
  );
}
