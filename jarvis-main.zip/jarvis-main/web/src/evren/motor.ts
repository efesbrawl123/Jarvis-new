// Evren · matematik çekirdeği (saf: React/DOM yok, test edilebilir).
// Dünya sabit çerçevesinde (boylam, enlem) → birim vektör → kameraya döndür → perspektif izdüşüm.

export const D = Math.PI / 180;
export const KM_R = 6371; // Dünya yarıçapı (km)
export const MU = 398600.4418; // Dünya çekim parametresi (km³/s²)
export const OMEGA_E = 7.2921159e-5; // Dünya'nın dönüş hızı (rad/s)

export interface V3 { x: number; y: number; z: number }
export interface Kamera { cx: number; cy: number; f: number; d: number }

export const normLon = (l: number) => {
  let x = (l + Math.PI) % (2 * Math.PI);
  if (x < 0) x += 2 * Math.PI;
  return x - Math.PI;
};
export const sinirla = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

/** Boylam/enlem (radyan) → vektör. x sağ, y yukarı, z izleyiciye doğru. */
export function llToVec(lon: number, lat: number, r = 1): V3 {
  const c = Math.cos(lat);
  return { x: r * c * Math.sin(lon), y: r * Math.sin(lat), z: r * c * Math.cos(lon) };
}

/** Dünya çerçevesinden kamera çerçevesine: (lon0, lat0) noktası ekranın ortasına (0,0,1) gelir. */
export function donder(v: V3, lon0: number, lat0: number): V3 {
  const cl = Math.cos(lon0), sl = Math.sin(lon0);
  const x1 = v.x * cl - v.z * sl;
  const z1 = v.x * sl + v.z * cl;
  const cp = Math.cos(lat0), sp = Math.sin(lat0);
  return { x: x1, y: v.y * cp - z1 * sp, z: v.y * sp + z1 * cp };
}

/** Perspektif izdüşüm; kameranın arkasındaysa null. */
export function izdusum(p: V3, k: Kamera): { x: number; y: number; olcek: number } | null {
  const den = k.d - p.z;
  if (den <= 0.05) return null;
  const s = k.f / den;
  return { x: k.cx + p.x * s, y: k.cy - p.y * s, olcek: s };
}

/** Birim küre YÜZEYİNDEKİ bir nokta kameraya bakıyor mu? (p kamera çerçevesinde birim vektör) */
export const yuzeyGorunur = (p: V3, d: number) => p.z * d > 1;

/** Küre dışındaki bir nokta (uydu) kürenin arkasında, kameradan görünmüyor mu? */
export function arkadaMi(p: V3, d: number): boolean {
  const dx = p.x, dy = p.y, dz = p.z - d;
  const a = dx * dx + dy * dy + dz * dz;
  const b = 2 * d * dz;
  const c = d * d - 1;
  const disc = b * b - 4 * a * c;
  if (disc <= 0 || a === 0) return false;
  const t1 = (-b - Math.sqrt(disc)) / (2 * a);
  return t1 > 0 && t1 < 1;
}

/** Ekrandaki küre siluet yarıçapı (px). */
export const kureYaricapPx = (k: Kamera) => k.f / Math.sqrt(Math.max(1e-6, k.d * k.d - 1));

// ------------------------------------------------------------------ Yörüngeler
export interface Yorunge { hKm: number; egim: number; dugum: number; faz: number }

/** Dairesel yörünge dönem süresi (saniye). */
export function periyot(hKm: number): number {
  const a = KM_R + hKm;
  return 2 * Math.PI * Math.sqrt((a * a * a) / MU);
}

/** t (sn) anında uydunun Dünya'ya göre alt-uydu noktası (radyan). */
export function yorungeKonum(t: number, o: Yorunge): { lon: number; lat: number } {
  const n = (2 * Math.PI) / periyot(o.hKm);
  const u = o.faz + n * t;
  const lat = Math.asin(sinirla(Math.sin(o.egim) * Math.sin(u), -1, 1));
  const lonI = o.dugum + Math.atan2(Math.cos(o.egim) * Math.sin(u), Math.cos(u));
  return { lon: normLon(lonI - OMEGA_E * t), lat };
}

/** Görsel için yükseklik sıkıştırması (ölçekli değil): LEO ≈ 0,19 · GPS ≈ 0,75 · GEO ≈ 0,98 Dünya yarıçapı. */
export const yukseklikGorsel = (hKm: number) => 0.08 + 0.9 * Math.sqrt(Math.min(1, hKm / 36000));

/** (lon, lat) merkezli, açısal yarıçapı rho olan küçük çember noktaları. */
export function halka(lon: number, lat: number, rho: number, n = 48): { lon: number; lat: number }[] {
  const out: { lon: number; lat: number }[] = [];
  for (let i = 0; i <= n; i++) {
    const th = (i / n) * 2 * Math.PI;
    const lat2 = Math.asin(sinirla(Math.sin(lat) * Math.cos(rho) + Math.cos(lat) * Math.sin(rho) * Math.cos(th), -1, 1));
    const lon2 = lon + Math.atan2(Math.sin(th) * Math.sin(rho) * Math.cos(lat), Math.cos(rho) - Math.sin(lat) * Math.sin(lat2));
    out.push({ lon: normLon(lon2), lat: lat2 });
  }
  return out;
}

/** Güneş'in tam tepede olduğu nokta (yaklaşık: ±4°). */
export function gunesNoktasi(ms: number): { lon: number; lat: number } {
  const d = new Date(ms);
  const yilBasi = Date.UTC(d.getUTCFullYear(), 0, 0);
  const gun = Math.floor((ms - yilBasi) / 86400000);
  const dec = 23.44 * D * Math.sin(((2 * Math.PI) / 365) * (gun - 81));
  const saat = d.getUTCHours() + d.getUTCMinutes() / 60 + d.getUTCSeconds() / 3600;
  return { lon: normLon((12 - saat) * 15 * D), lat: dec };
}

/** İki (lon, lat) arasındaki açısal uzaklık (radyan). */
export function acisalUzaklik(a: { lon: number; lat: number }, b: { lon: number; lat: number }): number {
  const c = Math.sin(a.lat) * Math.sin(b.lat) + Math.cos(a.lat) * Math.cos(b.lat) * Math.cos(a.lon - b.lon);
  return Math.acos(sinirla(c, -1, 1));
}

// ------------------------------------------------------------------ Güneş sistemi (dairesel yaklaşım)
export interface Govde {
  id: string; ad: string; aAU: number; donemGun: number; L0: number; renk: string; yaricapKm: number;
  cap: string; uzaklik: string; yil: string; gun: string; sicaklik: string; not?: string; bant?: boolean; halka?: boolean;
}

/** J2000'den bu yana gün. */
export const j2000Gun = (ms: number) => (ms - Date.UTC(2000, 0, 1, 12)) / 86400000;

/** Ekliptik düzlemde konum (AU): θ = ortalama boylam. Yaklaşık, dairesel yörünge. */
export function govdeKonum(g: Govde, gun: number): { x: number; z: number; aci: number } {
  const aci = (g.L0 + (360 * gun) / g.donemGun) * D;
  return { x: g.aAU * Math.cos(aci), z: -g.aAU * Math.sin(aci), aci };
}

/** Görsel yarıçap sıkıştırması (AU → sahne birimi). Merkür ≈ 0,9 · Neptün ≈ 5. */
export const aGorsel = (aAU: number) => 0.35 + 0.85 * Math.sqrt(aAU);

/** Güneş sistemi sahnesinde noktayı döndür: yaw (y ekseni), pitch (x ekseni). */
export function sahneDonder(v: V3, yaw: number, pitch: number): V3 {
  return donder(v, yaw, pitch);
}
