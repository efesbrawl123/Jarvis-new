// Evren · çizim motoru (saf fonksiyonlar: bir 2B bağlam ve durum alır, React/DOM bilmez).
// Üç görünüm: Dünya (kıyılar, uydular, meteor senaryosu), Güneş sistemi, gezegen yakın görünümü.
import { LAND } from '../data/world';
import {
  D, aGorsel, arkadaMi, donder, govdeKonum, gunesNoktasi, halka, izdusum, j2000Gun, kureYaricapPx, llToVec, normLon,
  periyot, sinirla, yorungeKonum, yukseklikGorsel, type Kamera, type V3,
} from './motor';
import { GOVDELER, ISS, TAKIMLAR, govdeBul, uyduListesi, type Takim } from './veri';
import { meteorEvre, type MeteorParam, type MeteorSonuc } from './senaryo';

export type Mod = 'dunya' | 'gunes' | 'gezegen';
export type Kalite = 'hafif' | 'dengeli' | 'yuksek';

export interface SenaryoDurum { t: number; p: MeteorParam; sonuc: MeteorSonuc }
export interface Isaret { lon: number; lat: number; ad: string; sicak?: boolean }

export interface EvrenDurum {
  mod: Mod;
  gezegenId: string;
  lon0: number; lat0: number; d: number;       // Dünya kamerası
  yaw: number; pitch: number; dGunes: number;  // Güneş sistemi kamerası
  spin: number; gezegenZoom: number;           // gezegen yakın görünümü
  uydular: boolean;
  simSn: number;                               // Dünya modu simülasyon saati (sn)
  simGun: number;                              // Güneş sistemi: J2000'den bu yana gün
  iss: { lon: number; lat: number } | null;    // gerçek ISS konumu (alınabildiyse)
  senaryo: SenaryoDurum | null;
  isaretler: Isaret[];
  eller: boolean;                              // kamera görüntüsü arkada: şeffaf çiz
  kalite: Kalite;
  rgb: string;                                 // vurgu rengi "77, 225, 255" (tema)
}

export function yeniDurum(): EvrenDurum {
  return {
    mod: 'dunya', gezegenId: 'mars', lon0: 29 * D, lat0: 28 * D, d: 3.3, yaw: 0.5, pitch: 0.9, dGunes: 9.5,
    spin: 0, gezegenZoom: 1, uydular: true, simSn: 0, simGun: 0, iss: null, senaryo: null,
    isaretler: [{ lon: 28.98 * D, lat: 41.01 * D, ad: 'İSTANBUL' }], eller: false, kalite: 'dengeli', rgb: '77, 225, 255',
  };
}

const kal = (S: EvrenDurum) => S.kalite;
const ac = (S: EvrenDurum, a: number) => `rgba(${S.rgb}, ${a})`;
const FONT = '600 12px Rajdhani, system-ui, sans-serif';

// ------------------------------------------------------------------ Önceden hesaplanan veriler
/** Kıyı halkaları: birim vektörler (x,y,z) olarak, bir kez. */
const RINGV: Float32Array[] = LAND.map(s => {
  const n = s.split(',').map(Number);
  const out = new Float32Array((n.length >> 1) * 3);
  for (let i = 0, j = 0; i + 1 < n.length; i += 2, j += 3) {
    const v = llToVec(n[i] * D, n[i + 1] * D);
    out[j] = v.x; out[j + 1] = v.y; out[j + 2] = v.z;
  }
  return out;
});

const UYDULAR = uyduListesi();
const YILDIZ: { x: number; y: number; r: number; a: number }[] = (() => {
  let s = 12345;
  const rnd = () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296);
  return Array.from({ length: 130 }, () => ({ x: rnd(), y: rnd(), r: 0.4 + rnd() * 1.1, a: 0.25 + rnd() * 0.6 }));
})();

/** Satır-öncelikli 3×3 döndürme matrisi: donder() ile aynı sonucu verir. */
export function matris(lon0: number, lat0: number): number[] {
  const cl = Math.cos(lon0), sl = Math.sin(lon0), cp = Math.cos(lat0), sp = Math.sin(lat0);
  return [cl, 0, -sl, -sp * sl, cp, -sp * cl, cp * sl, sp, cp * cl];
}

function kameraDunya(S: EvrenDurum, w: number, h: number): Kamera {
  return { cx: w / 2, cy: h * 0.45, f: Math.min(w, h) * 0.62, d: S.d };
}

type Nok = { x: number; y: number } | null;
function cizgi(ctx: CanvasRenderingContext2D, pts: Nok[]) {
  let on = false;
  ctx.beginPath();
  for (const q of pts) {
    if (!q) { on = false; continue; }
    if (on) ctx.lineTo(q.x, q.y); else ctx.moveTo(q.x, q.y);
    on = true;
  }
  ctx.stroke();
}

// ------------------------------------------------------------------ Arka plan
function arkaplan(ctx: CanvasRenderingContext2D, S: EvrenDurum, w: number, h: number) {
  ctx.clearRect(0, 0, w, h);
  if (S.eller) {
    ctx.fillStyle = 'rgba(2, 6, 12, 0.52)';
    ctx.fillRect(0, 0, w, h);
    return;
  }
  const g = ctx.createRadialGradient(w / 2, h * 0.45, 10, w / 2, h * 0.45, Math.max(w, h) * 0.8);
  g.addColorStop(0, '#07121d');
  g.addColorStop(1, '#010305');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
  const kayma = (S.mod === 'dunya' ? S.lon0 : S.yaw) * 14;
  for (const y of YILDIZ) {
    ctx.fillStyle = `rgba(210, 235, 255, ${y.a})`;
    const x = (((y.x * w - kayma) % w) + w) % w;
    ctx.fillRect(x, y.y * h, y.r, y.r);
  }
}

// ------------------------------------------------------------------ DÜNYA
function dunyaCiz(ctx: CanvasRenderingContext2D, S: EvrenDurum, w: number, h: number, nowMs: number) {
  const k = kameraDunya(S, w, h);
  const R = kureYaricapPx(k);
  const { cx, cy, d } = k;
  const m = matris(S.lon0, S.lat0);

  // Atmosfer parıltısı ve küre
  const atm = ctx.createRadialGradient(cx, cy, R * 0.96, cx, cy, R * 1.22);
  atm.addColorStop(0, ac(S, 0.35));
  atm.addColorStop(1, ac(S, 0));
  ctx.fillStyle = atm;
  ctx.beginPath(); ctx.arc(cx, cy, R * 1.22, 0, Math.PI * 2); ctx.fill();
  const g = ctx.createRadialGradient(cx - R * 0.35, cy - R * 0.35, R * 0.1, cx, cy, R);
  g.addColorStop(0, ac(S, 0.2));
  g.addColorStop(1, ac(S, 0.04));
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = ac(S, 0.6);
  ctx.lineWidth = 1.2;
  ctx.stroke();

  const yuzey = (lon: number, lat: number): Nok => {
    const v = donder(llToVec(lon, lat), S.lon0, S.lat0);
    if (v.z * d <= 1) return null;
    const p = izdusum(v, k);
    return p ? { x: p.x, y: p.y } : null;
  };

  // Izgara (30°)
  ctx.strokeStyle = ac(S, 0.14);
  ctx.lineWidth = 0.8;
  for (let l = -180; l < 180; l += 30) cizgi(ctx, Array.from({ length: 37 }, (_, i) => yuzey(l * D, (-90 + i * 5) * D)));
  for (let p = -60; p <= 60; p += 30) cizgi(ctx, Array.from({ length: 73 }, (_, i) => yuzey((-180 + i * 5) * D, p * D)));

  // Kıyılar
  ctx.strokeStyle = ac(S, 0.85);
  ctx.lineWidth = 1;
  const adim = kal(S) === 'hafif' ? 2 : 1;
  for (const r of RINGV) {
    let on = false;
    ctx.beginPath();
    for (let i = 0; i < r.length; i += 3 * adim) {
      const x = r[i], y = r[i + 1], z = r[i + 2];
      const z2 = m[6] * x + m[7] * y + m[8] * z;
      if (z2 * d <= 1) { on = false; continue; }
      const x2 = m[0] * x + m[1] * y + m[2] * z;
      const y2 = m[3] * x + m[4] * y + m[5] * z;
      const s = k.f / (d - z2);
      const px = cx + x2 * s, py = cy - y2 * s;
      if (on) ctx.lineTo(px, py); else ctx.moveTo(px, py);
      on = true;
    }
    ctx.stroke();
  }

  // Gündüz-gece sınırı (terminatör) ve Güneş noktası
  const gunes = gunesNoktasi(nowMs);
  ctx.strokeStyle = 'rgba(255, 190, 90, 0.28)';
  ctx.setLineDash([4, 5]);
  ctx.lineWidth = 1;
  cizgi(ctx, halka(gunes.lon, gunes.lat, Math.PI / 2, 90).map(p => yuzey(p.lon, p.lat)));
  ctx.setLineDash([]);
  const gp = yuzey(gunes.lon, gunes.lat);
  if (gp) {
    const gg = ctx.createRadialGradient(gp.x, gp.y, 0, gp.x, gp.y, 16);
    gg.addColorStop(0, 'rgba(255, 220, 120, 0.9)');
    gg.addColorStop(1, 'rgba(255, 220, 120, 0)');
    ctx.fillStyle = gg;
    ctx.beginPath(); ctx.arc(gp.x, gp.y, 16, 0, Math.PI * 2); ctx.fill();
  }

  // İşaretler
  ctx.font = FONT;
  ctx.textBaseline = 'middle';
  for (const mk of S.isaretler) {
    const q = yuzey(mk.lon, mk.lat);
    if (!q) continue;
    const nabiz = (nowMs / 1200 + mk.lon) % 1;
    ctx.strokeStyle = mk.sicak ? `rgba(255, 190, 90, ${1 - nabiz})` : `rgba(160, 235, 255, ${1 - nabiz})`;
    ctx.beginPath(); ctx.arc(q.x, q.y, 3 + nabiz * 12, 0, Math.PI * 2); ctx.stroke();
    ctx.fillStyle = mk.sicak ? '#ffc46b' : '#dff7ff';
    ctx.beginPath(); ctx.arc(q.x, q.y, 2.6, 0, Math.PI * 2); ctx.fill();
    ctx.fillText(mk.ad, q.x + 8, q.y);
  }

  uydularCiz(ctx, S, k);
  if (S.senaryo) meteorCiz(ctx, S, k, R, nowMs);
}

function uydularCiz(ctx: CanvasRenderingContext2D, S: EvrenDurum, k: Kamera) {
  const { d } = k;
  const nokta = (lon: number, lat: number, r: number): { x: number; y: number } | null => {
    const v = donder(llToVec(lon, lat, r), S.lon0, S.lat0);
    if (arkadaMi(v, d)) return null;
    const p = izdusum(v, k);
    return p ? { x: p.x, y: p.y } : null;
  };

  if (S.uydular) {
    const liste = kal(S) === 'hafif' ? UYDULAR.filter((_, i) => i % 2 === 0) : UYDULAR;
    for (const u of liste) {
      const { lon, lat } = yorungeKonum(S.simSn, u.y);
      const q = nokta(lon, lat, 1 + yukseklikGorsel(u.y.hKm));
      if (!q) continue;
      ctx.fillStyle = u.takim.renk;
      ctx.fillRect(q.x - 1.2, q.y - 1.2, 2.4, 2.4);
    }
  }

  // ISS: iz (yaklaşık yarım yörünge) + işaret. Gerçek konum alınabildiyse o, değilse temsili yörünge.
  const rIss = 1 + yukseklikGorsel(ISS.hKm);
  const T = periyot(ISS.hKm);
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
  ctx.lineWidth = 1;
  const iz: Nok[] = [];
  for (let i = 0; i <= 48; i++) {
    const p = yorungeKonum(S.simSn + (i / 48) * (T * 0.45), ISS);
    iz.push(nokta(p.lon, p.lat, rIss));
  }
  if (!S.iss) cizgi(ctx, iz);
  const ip = S.iss ? { lon: S.iss.lon, lat: S.iss.lat } : yorungeKonum(S.simSn, ISS);
  const q = nokta(ip.lon, ip.lat, rIss);
  if (q) {
    ctx.fillStyle = '#ffffff';
    ctx.beginPath(); ctx.arc(q.x, q.y, 3.2, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.55)';
    ctx.beginPath(); ctx.arc(q.x, q.y, 7, 0, Math.PI * 2); ctx.stroke();
    ctx.font = FONT;
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#ffffff';
    ctx.fillText(S.iss ? 'ISS · GERÇEK KONUM' : 'ISS · TEMSİLİ', q.x + 11, q.y);
  }
}

// ------------------------------------------------------------------ METEOR SENARYOSU
const kolay = (x: number) => 1 - Math.pow(1 - sinirla(x, 0, 1), 3);

function meteorCiz(ctx: CanvasRenderingContext2D, S: EvrenDurum, k: Kamera, R: number, nowMs: number) {
  const sn = S.senaryo!;
  const { evre, k: ke } = meteorEvre(sn.t);
  if (evre === 'bitti') return;
  const { lon, lat } = sn.p;
  const hedef = llToVec(lon, lat, 1);
  const yer = donder(hedef, S.lon0, S.lat0);
  const gorunur = yer.z * k.d > 1;
  const pq = izdusum(yer, k);

  if (evre === 'yaklasma') {
    // Giriş yönü: yerel "yukarı" ve "doğu" karışımı (çarpma açısına göre)
    const dogu: V3 = { x: Math.cos(lon), y: 0, z: -Math.sin(lon) };
    const a = sn.p.aciDeg * D;
    const u: V3 = { x: hedef.x * Math.sin(a) + dogu.x * Math.cos(a), y: hedef.y * Math.sin(a) + dogu.y * Math.cos(a), z: hedef.z * Math.sin(a) + dogu.z * Math.cos(a) };
    const un = Math.hypot(u.x, u.y, u.z) || 1;
    const s = 5.5 * Math.pow(1 - ke, 1.7);
    const kon = (mesafe: number) => {
      const v = donder({ x: hedef.x + (u.x / un) * mesafe, y: hedef.y + (u.y / un) * mesafe, z: hedef.z + (u.z / un) * mesafe }, S.lon0, S.lat0);
      return arkadaMi(v, k.d) ? null : izdusum(v, k);
    };
    const bas = kon(s);
    const kuyruk = kon(s + 0.9 + 0.6 * ke);
    if (bas && kuyruk) {
      const g = ctx.createLinearGradient(kuyruk.x, kuyruk.y, bas.x, bas.y);
      g.addColorStop(0, 'rgba(255, 120, 40, 0)');
      g.addColorStop(1, 'rgba(255, 200, 120, 0.95)');
      ctx.strokeStyle = g;
      ctx.lineWidth = 2 + 5 * ke;
      ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(kuyruk.x, kuyruk.y); ctx.lineTo(bas.x, bas.y); ctx.stroke();
      ctx.lineCap = 'butt';
      const r = 4 + 18 * ke;
      const hg = ctx.createRadialGradient(bas.x, bas.y, 0, bas.x, bas.y, r * 2);
      hg.addColorStop(0, 'rgba(255, 245, 210, 1)');
      hg.addColorStop(0.35, 'rgba(255, 170, 70, 0.7)');
      hg.addColorStop(1, 'rgba(255, 80, 20, 0)');
      ctx.fillStyle = hg;
      ctx.beginPath(); ctx.arc(bas.x, bas.y, r * 2, 0, Math.PI * 2); ctx.fill();
    }
    return;
  }

  // Çarpma sonrası: nokta görünüyorsa patlama, şok dalgası, parçalar
  const enerjiOlcek = sinirla(0.16 + 0.13 * Math.log10(1 + sn.sonuc.megaton), 0.12, 1.45);
  if (gorunur && pq) {
    const t2 = evre === 'patlama' ? ke * 0.25 : evre === 'dalga' ? 0.25 + 0.6 * ke : 0.85 + 0.15 * ke;
    // Parlama
    if (evre === 'patlama') {
      const r = R * (0.06 + 0.5 * kolay(ke));
      const fg = ctx.createRadialGradient(pq.x, pq.y, 0, pq.x, pq.y, r);
      fg.addColorStop(0, `rgba(255, 255, 255, ${1 - ke * 0.4})`);
      fg.addColorStop(0.4, `rgba(255, 200, 100, ${0.8 * (1 - ke)})`);
      fg.addColorStop(1, 'rgba(255, 90, 20, 0)');
      ctx.fillStyle = fg;
      ctx.beginPath(); ctx.arc(pq.x, pq.y, r, 0, Math.PI * 2); ctx.fill();
    }
    // Parçalar (çözümsel, durumsuz)
    if (evre !== 'kul') {
      const tt = evre === 'patlama' ? ke * 0.3 : 0.3 + 0.7 * ke;
      const adet = kal(S) === 'hafif' ? 22 : 44;
      for (let i = 0; i < adet; i++) {
        const ang = i * 2.399963;
        const hiz = R * (0.12 + 0.5 * (((i * 0.618) % 1)));
        const px = pq.x + Math.cos(ang) * hiz * tt;
        const py = pq.y - Math.sin(ang) * hiz * tt * 0.55 + 0.5 * R * 0.9 * tt * tt;
        ctx.fillStyle = `rgba(255, ${150 + (i % 5) * 20}, 70, ${Math.max(0, 1 - tt)})`;
        ctx.fillRect(px, py, 2.2, 2.2);
      }
    }
    // Krater parıltısı
    const kg = ctx.createRadialGradient(pq.x, pq.y, 0, pq.x, pq.y, 14 + 10 * enerjiOlcek);
    kg.addColorStop(0, `rgba(255, 130, 40, ${0.75 * (1 - (evre === 'kul' ? ke : 0) * 0.7)})`);
    kg.addColorStop(1, 'rgba(255, 60, 10, 0)');
    ctx.fillStyle = kg;
    ctx.beginPath(); ctx.arc(pq.x, pq.y, 14 + 10 * enerjiOlcek, 0, Math.PI * 2); ctx.fill();
    void t2;
  }
  // Şok dalgası: yüzey boyunca genişleyen halkalar
  if (evre === 'dalga' || evre === 'kul') {
    const kk = evre === 'dalga' ? ke : 1;
    for (let j = 0; j < 3; j++) {
      const gec = j * 0.18;
      const kj = sinirla((kk - gec) / (1 - gec), 0, 1);
      if (kj <= 0) continue;
      const rho = enerjiOlcek * kolay(kj);
      const a = (1 - kj) * (evre === 'kul' ? 1 - ke : 1) * 0.8;
      if (a <= 0.01) continue;
      ctx.strokeStyle = `rgba(255, ${180 - j * 30}, ${90 - j * 20}, ${a})`;
      ctx.lineWidth = 2.4 - j * 0.5;
      cizgi(ctx, halka(lon, lat, Math.max(0.001, rho), 72).map(p => {
        const v = donder(llToVec(p.lon, p.lat), S.lon0, S.lat0);
        if (v.z * k.d <= 1) return null;
        const q = izdusum(v, k);
        return q ? { x: q.x, y: q.y } : null;
      }));
    }
  }
  void nowMs;
}

// ------------------------------------------------------------------ GÜNEŞ SİSTEMİ
function gunesKamera(S: EvrenDurum, w: number, h: number): Kamera {
  return { cx: w / 2, cy: h * 0.45, f: Math.min(w, h) * 0.62, d: S.dGunes };
}
function sahneNokta(S: EvrenDurum, k: Kamera, x: number, y: number, z: number) {
  const v = donder({ x, y, z }, S.yaw, S.pitch);
  return izdusum(v, k);
}
const govdePx = (yaricapKm: number, olcek: number) => Math.max(2.4, Math.min(16, (1.2 + Math.log10(yaricapKm) * 1.1) * Math.min(2.2, Math.max(0.8, olcek / 60))));

export interface GovdeNokta { id: string; x: number; y: number; r: number }

/** Ekrandaki gezegen konumları (çizim ve dokunma için ortak). */
export function gunesNoktalari(S: EvrenDurum, w: number, h: number): GovdeNokta[] {
  const k = gunesKamera(S, w, h);
  const out: GovdeNokta[] = [];
  for (const g of GOVDELER) {
    let x = 0, z = 0;
    if (g.aAU > 0) {
      const p = govdeKonum(g, S.simGun);
      const r = aGorsel(g.aAU);
      const u = Math.hypot(p.x, p.z) || 1;
      x = (p.x / u) * r; z = (p.z / u) * r;
    }
    const q = sahneNokta(S, k, x, 0, z);
    if (!q) continue;
    out.push({ id: g.id, x: q.x, y: q.y, r: g.id === 'gunes' ? 14 : govdePx(g.yaricapKm, q.olcek) });
  }
  return out;
}

function gunesCiz(ctx: CanvasRenderingContext2D, S: EvrenDurum, w: number, h: number) {
  const k = gunesKamera(S, w, h);
  // Yörünge çizgileri
  ctx.lineWidth = 0.8;
  for (const g of GOVDELER) {
    if (g.aAU <= 0) continue;
    const r = aGorsel(g.aAU);
    ctx.strokeStyle = g.id === 'dunya' ? ac(S, 0.4) : ac(S, 0.16);
    cizgi(ctx, Array.from({ length: 97 }, (_, i) => {
      const a = (i / 96) * Math.PI * 2;
      return sahneNokta(S, k, Math.cos(a) * r, 0, Math.sin(a) * r);
    }));
  }
  // Güneş parıltısı
  const gp = sahneNokta(S, k, 0, 0, 0);
  if (gp) {
    const rr = 30 * Math.min(2.2, Math.max(0.8, gp.olcek / 60));
    const g = ctx.createRadialGradient(gp.x, gp.y, 0, gp.x, gp.y, rr * 2.4);
    g.addColorStop(0, 'rgba(255, 240, 190, 1)');
    g.addColorStop(0.25, 'rgba(255, 190, 80, 0.8)');
    g.addColorStop(1, 'rgba(255, 120, 20, 0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(gp.x, gp.y, rr * 2.4, 0, Math.PI * 2); ctx.fill();
  }
  ctx.font = FONT;
  ctx.textBaseline = 'middle';
  for (const n of gunesNoktalari(S, w, h)) {
    if (n.id === 'gunes') continue;
    const g = govdeBul(n.id)!;
    ctx.fillStyle = g.renk;
    ctx.beginPath(); ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2); ctx.fill();
    if (g.halka) {
      ctx.strokeStyle = 'rgba(227, 207, 156, 0.7)';
      ctx.lineWidth = 1.4;
      ctx.beginPath(); ctx.ellipse(n.x, n.y, n.r * 2, n.r * 0.7, -0.3, 0, Math.PI * 2); ctx.stroke();
    }
    ctx.fillStyle = 'rgba(223, 247, 255, 0.92)';
    ctx.fillText(g.ad.toLocaleUpperCase('tr'), n.x + n.r + 5, n.y);
  }
}

// ------------------------------------------------------------------ GEZEGEN YAKIN GÖRÜNÜM
function gezegenCiz(ctx: CanvasRenderingContext2D, S: EvrenDurum, w: number, h: number) {
  const g = govdeBul(S.gezegenId) ?? GOVDELER[4];
  const cx = w / 2, cy = h * 0.42;
  const R = Math.min(w, h) * 0.3 * sinirla(S.gezegenZoom, 0.5, 2.2);

  // Satürn halkası (arka yarım)
  const halkaCiz = (on: boolean) => {
    if (!g.halka) return;
    ctx.strokeStyle = 'rgba(227, 207, 156, 0.75)';
    for (let i = 0; i < 4; i++) {
      ctx.lineWidth = 3.5 - i * 0.6;
      ctx.beginPath();
      ctx.ellipse(cx, cy, R * (1.5 + i * 0.16), R * (0.42 + i * 0.045), -0.28, on ? 0 : Math.PI, on ? Math.PI : Math.PI * 2);
      ctx.stroke();
    }
  };
  halkaCiz(false);

  // Gövde
  const parlak = ctx.createRadialGradient(cx - R * 0.4, cy - R * 0.4, R * 0.1, cx, cy, R);
  parlak.addColorStop(0, g.renk);
  parlak.addColorStop(1, '#05070a');
  ctx.save();
  ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.clip();
  ctx.fillStyle = parlak;
  ctx.fillRect(cx - R, cy - R, R * 2, R * 2);
  if (g.bant) {
    // Bulut bantları (enleme paralel), dönüşle hafifçe kayar
    for (let i = -8; i <= 8; i++) {
      const y = cy + (i / 8) * R * 0.95;
      const a = 0.1 + 0.1 * Math.sin(i * 1.7 + S.spin * 0.6);
      ctx.fillStyle = `rgba(90, 60, 30, ${a})`;
      ctx.fillRect(cx - R, y - R * 0.04, R * 2, R * 0.075);
    }
  }
  // Yüzey lekeleri: dönüşle kayar (tohumlu, sabit)
  for (let i = 0; i < 9; i++) {
    const fx = (((i * 0.37 + S.spin * 0.05) % 1) + 1) % 1;
    const x = cx - R + fx * R * 2;
    const y = cy + Math.sin(i * 2.3) * R * 0.6;
    ctx.fillStyle = `rgba(0, 0, 0, ${0.12 + (i % 3) * 0.04})`;
    ctx.beginPath(); ctx.ellipse(x, y, R * (0.1 + (i % 4) * 0.03), R * 0.07, 0, 0, Math.PI * 2); ctx.fill();
  }
  // Gece tarafı gölgesi
  const gol = ctx.createLinearGradient(cx - R, cy, cx + R, cy);
  gol.addColorStop(0, 'rgba(0,0,0,0)');
  gol.addColorStop(0.55, 'rgba(0,0,0,0.1)');
  gol.addColorStop(1, 'rgba(0,0,0,0.78)');
  ctx.fillStyle = gol;
  ctx.fillRect(cx - R, cy - R, R * 2, R * 2);
  ctx.restore();
  halkaCiz(true);
  const kenar = ctx.createRadialGradient(cx, cy, R * 0.97, cx, cy, R * 1.12);
  kenar.addColorStop(0, ac(S, 0.35));
  kenar.addColorStop(1, ac(S, 0));
  ctx.fillStyle = kenar;
  ctx.beginPath(); ctx.arc(cx, cy, R * 1.12, 0, Math.PI * 2); ctx.fill();

  if (g.id === 'gunes') {
    const korona = ctx.createRadialGradient(cx, cy, R * 0.8, cx, cy, R * 1.6);
    korona.addColorStop(0, 'rgba(255, 200, 100, 0.55)');
    korona.addColorStop(1, 'rgba(255, 120, 20, 0)');
    ctx.fillStyle = korona;
    ctx.beginPath(); ctx.arc(cx, cy, R * 1.6, 0, Math.PI * 2); ctx.fill();
  }
}

// ------------------------------------------------------------------ Ana çizim
export function cizEvren(ctx: CanvasRenderingContext2D, S: EvrenDurum, w: number, h: number, nowMs: number): void {
  arkaplan(ctx, S, w, h);
  if (S.mod === 'dunya') dunyaCiz(ctx, S, w, h, nowMs);
  else if (S.mod === 'gunes') gunesCiz(ctx, S, w, h);
  else gezegenCiz(ctx, S, w, h);
}

/** Takım adı ve rengi (açıklama etiketi için). */
export const TAKIM_LISTESI: Takim[] = TAKIMLAR;

/** Dünya modunda ekran merkezinin (lon, lat) bilgisini normalleştir. */
export function odakla(S: EvrenDurum, lon: number, lat: number) {
  S.lon0 = normLon(lon);
  S.lat0 = sinirla(lat, -85 * D, 85 * D);
}

/** Meteor senaryosu başlat (kamerayı hedefe çevirmek bileşenin işidir). */
export function senaryoBaslat(S: EvrenDurum, p: MeteorParam, sonuc: MeteorSonuc) {
  S.senaryo = { t: 0, p, sonuc };
  S.isaretler = S.isaretler.filter(m => !m.sicak);
  S.isaretler.push({ lon: p.lon, lat: p.lat, ad: p.ad.toLocaleUpperCase('tr'), sicak: true });
}

/** Güneş sistemi tarihini (gün) şimdiye ayarla. */
export const simdiGun = (ms: number) => j2000Gun(ms);
