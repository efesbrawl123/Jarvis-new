# J.A.R.V.I.S. – El Modu / 50 Evren Özelliği

## Kullanım
1. El Kontrolü ekranını açın ve kamera iznini verin.
2. **EVREN MODU** düğmesine basın.
3. **50 EL ÖZELLİĞİ** panelinden bir komut seçin. Komut seçildiğinde Evren simülasyonuna uygulanır.
4. Panel açıkken temel el jestleri de çalışmaya devam eder.

## Temel el jestleri
- Açık el: Dünya'yı sürükleyerek döndürür; yumruktan açık ele geçiş simülasyonu devam ettirir.
- İki el: Eller arasındaki mesafe ile yakınlaştırma/uzaklaştırma, iki avuç ortası ile kamera yönü.
- Çimdik: Tek elle yakınlaştırma/uzaklaştırma.
- Zafer işareti: Uydu katmanını açıp kapatır.
- Üç parmak: Dünya / Güneş sistemi / gezegen görünümleri arasında geçiş yapar.
- İşaret parmağı: Canlı ISS koordinatı mevcutsa ona odaklanır.
- Yumruk: Simülasyonu duraklatır.
- Başparmak: Dünya kamera görünümünü başlangıca alır.
- Boynuz işareti: Uydu katmanını açıp kapatır.
- Telefon işareti: HUD vurgusunu mavi/yeşil arasında değiştirir.

## 50 panel komutu
1 Dünya görünümü · 2 Kuzey kutbu · 3 Güney kutbu · 4 Ekvator görünümü · 5 Türkiye odağı
6 Avrupa odağı · 7 Asya odağı · 8 Amerika odağı · 9 Yakınlaş · 10 Uzaklaş
11 Kamera sıfırla · 12 Uyduları göster · 13 Uyduları gizle · 14 Uydu animasyonunu hızlandır · 15 Uydu animasyonunu yavaşlat
16 Bir saat ileri · 17 Bir tur ileri · 18 ISS konumuna odaklan · 19 ISS izini merkeze al · 20 Uydu görünümünü sıfırla
21 Güneş sistemi · 22 Gezegen modu · 23 Güneş sistemi yakınlaştır · 24 Güneş sistemi uzaklaştır · 25 Yörünge açısını sola çevir
26 Yörünge açısını sağa çevir · 27 Yörüngeyi yukarı eğ · 28 Yörüngeyi aşağı eğ · 29 Simülasyonu 1 gün ilerlet · 30 Simülasyonu 30 gün ilerlet
31 J2000 tarihine dön · 32 İstanbul işareti ekle · 33 Şanlıurfa işareti ekle · 34 Ankara işareti ekle · 35 İzmir işareti ekle
36 İşaretleri temizle · 37 İşaretleri varsayılana döndür · 38 Yüksek kalite · 39 Dengeli kalite · 40 Hafif kalite
41 Mavi HUD rengi · 42 Yeşil HUD rengi · 43 Altın HUD rengi · 44 Mor HUD rengi · 45 Pembe HUD rengi
46 Zamanı 10 dakika ilerlet · 47 Zamanı 10 dakika geri al · 48 Gezegen yılına ilerle · 49 Kamera eğimini sıfırla · 50 Kamera boylamını sıfırla

## Veri doğruluğu
ISS yalnızca konum API'sinden veri alınabildiğinde canlı olarak etiketlenir. Diğer uydu noktaları mevcut Evren motorunun yörünge matematiğine dayalı görselleştirmelerdir; gerçek zamanlı telemetri olarak sunulmaz. Zamanı ileri/geri alan komutlar simülasyon saatini değiştirir, gerçek uyduyu fiziksel olarak kontrol etmez.

## GitHub derleme
`web` dizininde `npm ci` ve `npm run build` çalıştırılmalıdır. `node_modules` arşive dahil edilmez; bağımlılıklar kilit dosyasından temiz biçimde kurulur. Derleme başarısı GitHub Actions loglarında `tsc -b` ve `vite build` adımlarının yeşil tamamlanmasıyla doğrulanmalıdır.
