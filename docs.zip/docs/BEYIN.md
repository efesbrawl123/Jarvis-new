# Çok sağlayıcılı beyin

Jarvis birden fazla yapay zekâ sağlayıcısını aynı anda kullanır. Anahtarları **Render → servis → Environment** bölümüne girersin, gerisini kendisi halleder.

## Anahtarları gir

Her sağlayıcı için ayrı değişken (hepsi isteğe bağlı, kaç tane girersen o kadar çalışır):

| Değişken | Sağlayıcı | Anahtar nasıl görünür |
|---|---|---|
| `GEMINI_API_KEY` | Google Gemini | `AIza…` |
| `OPENAI_API_KEY` | OpenAI | `sk-…` / `sk-proj-…` |
| `ANTHROPIC_API_KEY` | Claude | `sk-ant-…` |
| `XAI_API_KEY` | Grok (xAI) | `xai-…` |
| `GROQ_API_KEY` | Groq | `gsk_…` |
| `OPENROUTER_API_KEY` | OpenRouter | `sk-or-…` |
| `DEEPSEEK_API_KEY` | DeepSeek | — |
| `MISTRAL_API_KEY` | Mistral | — |

**Ya da hepsini tek değişkende:** `API_ANAHTARLARI` = anahtarları boşluk, virgül ya da alt alta yazarak (başındaki harflerden hangi sağlayıcı olduğu anlaşılır; DeepSeek ve Mistral için ayrı değişken kullan). Eski `ABACUS_API_KEY` / `LLM_API_KEY` alanına Gemini, Claude, OpenAI ya da Grok anahtarı yapıştırılsa bile doğru sağlayıcıya yönlenir.

Anahtarın başında ya da sonunda boşluk, tırnak ya da satır sonu kalmasın.

## Kim hangi işi yapar

Her istek işine göre sağlayıcıya yönlenir:

| İş | Ne zaman | Varsayılan sıra |
|---|---|---|
| **sohbet** (hızlı) | Kısa günlük konuşma, araç çağırma | Gemini → OpenAI → Claude → Grok → … |
| **derin** (güçlü) | Uzun ya da analiz isteyen mesaj, gündem brifingi, "karşılaştır", "ayrıntılı", "neden" | Claude → OpenAI → Grok → Gemini → … |
| **görüntü/ses** | Fotoğraf, kamera, kitaplık taraması, ses girdisi | Gemini → OpenAI → Claude → Grok → … |

Sağlayıcı **hata verirse** (anahtar geçersiz, limit doldu, model kapandı, sunucu çöktü) otomatik sıradakine geçilir; hatalı sağlayıcı bir süre sona alınır (limit: 1 dk, sunucu: 30 sn, anahtar: 10 dk). Cevap akmaya başladıktan sonra kopma olursa yarım cevap başka sağlayıcıyla birleştirilmez.

**Model adlarını yazman gerekmez.** Jarvis her sağlayıcının kendi model listesinden role uygun en yeni modeli seçer (hızlı işe mini/haiku/flash, derin işe tam model; pahalı "pro/opus" ailelerini kendiliğinden seçmez). Liste alınamazsa tahmini adlara döner.

## İstersen ayarla (hepsi isteğe bağlı)

| Değişken | Anlamı |
|---|---|
| `BEYIN_MOD` | `hizli` (hep hızlı modeller) · `guclu` (hep güçlü modeller) · `dengeli` (varsayılan, işe göre) |
| `BEYIN_SOHBET`, `BEYIN_DERIN`, `BEYIN_GORSEL` | Sağlayıcı sırası, ör. `anthropic,openai`; yazdıkların öne geçer, kalanlar yedek olur |
| `BEYIN_SADECE=1` | Yedek sağlayıcıları kapat, yalnızca yazdığın sırayı kullan |
| `OPENAI_MODEL`, `OPENAI_MODEL_DERIN`, `ANTHROPIC_MODEL_SOHBET`… | Model adını elle belirle (`<SAĞLAYICI>_MODEL`, `_MODEL_SOHBET`, `_MODEL_DERIN`, `_MODEL_GORSEL`) |
| `LLM_DUSUNME` | `low`/`medium`/`high`: düşünen modellerde düşünme düzeyi (hız için varsayılan `low`); `kapali` gönderme |
| `<SAĞLAYICI>_BASE_URL` | Adresi değiştir (ör. kendi proxy'n) |

## Çalışıyor mu, nasıl bakarım

Jarvis'te **Ayarlar → Tanı**:
- **Beyin durumu:** hangi sağlayıcılar tanındı, hangi modeller seçildi, sağlıklı mı, son hata ne, hangi iş için sıra ne.
- **Beyni dene:** her sağlayıcıya küçük bir istek atar; ✓ (süre, model) ya da ✗ (neden: anahtar geçersiz, limit, …) gösterir.
- **Sesi dene:** telefonun sesi çalıyor mu.
- **Sürüm:** yama uygulandıysa "v5 · çok sağlayıcılı beyin" yazar.

Render'ın **Logs** ekranında açılışta şu satırlar görünür: `[beyin] 3 sağlayıcı: …` ve her iş için sıra.

## Dikkat
- Her sağlayıcı kendi kotasından ve ücretinden düşer. Claude, OpenAI ve Grok genellikle ücretlidir; "derin" işler pahalı modellere gidebilir. Maliyeti sınırlamak için `BEYIN_MOD=hizli` kullan ya da ücretli anahtarları girme.
- Sağlayıcının hizmet kullanımında konuşmalarının o sağlayıcıya gittiğini unutma (profil, kamera karesi, kitap notları dahil).
- Ses (TTS) ve ses→yazı hâlâ ayrı çalışır: Gemini'nin ses modeli ya da tarayıcı sesi.
