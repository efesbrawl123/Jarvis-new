# 3 Kasım 2026 — J.A.R.V.I.S. HUD arayüz güncellemesi

## Uygulananlar
- Mark II üst çubuğuna J.A.R.V.I.S. marka başlığı ve reaktör simgesi eklendi.
- Sağ panele izin gerektiren kamera kartı ve mevcut canlı kamera panelini açan düğme eklendi.
- Mevcut kamera davranışı korundu: kullanıcı kamera cihazında başlatır/durdurur; izleyici paneli P2P bağlantıyı dener, gerekirse aralıklı kareye geçer; Jarvis'in bakışında tarama ve kısa kare dondurma efekti sürer.
- Kamera panelinin HUD tarama çizgileri, retikülü, köşe çerçevesi ve mavi ışık efektleri güçlendirildi.
- Dünya görünümüne görsel doku eklendi; mevcut canvas üzerindeki dönen koordinat ızgarası ve konum işaretleri korunur.
- GitHub Actions için web derleme kontrolü eklendi. Derleme adımı hata verirse workflow başarısız olur; hataları gizleyen `continue-on-error` kullanılmaz.
- iPhone/iPad üzerinden GitHub'a dosya yüklemek için ayrı rehber eklendi.

## Bilinçli sınırlar
- Kamera otomatik açılmaz; tarayıcı/kamera izni ve kullanıcının başlatması gerekir.
- Kamera kartındaki retikül/süpürme animasyonu arayüz efektidir; kamera görüntüsü yokken gerçek çevre analizi yapıldığı anlamına gelmez.
- Dünya dokusu bir arayüz görselidir; canlı uydu görüntüsü veya gerçek zamanlı Dünya yüzeyi verisi değildir.
- ISS/uydu/gezegen canlı veri özellikleri bu güncellemede genişletilmedi.
- Bu ortamda `npm ci` ağ kurulumu zaman aşımına uğradığı için `npm run build` tamamlanamadı. GitHub Actions workflow'u gerçek derlemeyi depo yüklendikten sonra yapacak. Yeşil workflow sonucu görülmeden derleme başarılı sayılmamalıdır.
