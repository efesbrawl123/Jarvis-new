# J.A.R.V.I.S. — El hareketleriyle Evren kontrolü

Evren görünümü artık El Kontrolü (`HandControl`) ekranına bağlandı. El takibi MediaPipe ile tarayıcıda yapılır; kamera görüntüsü sunucuya aktarılmaz.

## Kullanım

1. JARVIS'te **El Kontrolü** ekranını aç ve kamera iznini ver.
2. Üstteki **EVREN MODU** düğmesine bas.
3. Kamera elini gördüğünde:
   - **Açık el (✋):** Elini sağa/sola ve yukarı/aşağı hareket ettirerek Dünya'yı döndür.
   - **İki el:** Ellerini birbirinden ayırıp yaklaştırarak yakınlaş/uzaklaş; iki elin orta noktasını hareket ettirerek görünümü çevir.
   - **Çimdik (🤏):** Elini yukarı/aşağı hareket ettirerek yakınlaş/uzaklaş.
   - **Zafer işareti (✌️):** Uydu katmanını aç/kapat.
   - **Üç parmak (🖖):** Dünya / Güneş sistemi / gezegen görünümü arasında geçiş yap.
   - **İşaret parmağı (☝️):** ISS'nin canlı konumu alınabiliyorsa Dünya'yı ISS konumuna odakla.
   - **Yumruk (✊):** Simülasyonu duraklat.
   - **Açık el:** Simülasyonu yeniden oynat.
   - **Başparmak (👍):** Dünya görünümünü başlangıç konumuna döndür.
4. Ekrandaki düğmelerle de görünüm, uydu katmanı, yakınlaştırma ve duraklatma kontrol edilebilir.

## Veri doğruluğu

- ISS enlem/boylamı `https://api.wheretheiss.at/v1/satellites/25544` kaynağından 5 saniyede bir alınır. Ağ, CORS veya servis hatasında arayüz simülasyon moduna geri döner.
- Diğer uydu noktaları ve yörüngeleri şu an **temsili simülasyondur**; canlı telemetri değildir. Ekran ISS için canlı/simülasyon durumunu ayrı gösterir.
- Uydu yörünge çizimleri mevcut `evren` matematik motorunu kullanır.

## GitHub derleme

Repo kökünden `npm ci` ve `npm run build` komutları GitHub Actions üzerinde çalıştırılmalıdır. Bu çalışma ortamında bağımlılık kurulumu zaman aşımına uğradığı için yerel TypeScript/Vite derlemesi doğrulanamamıştır. GitHub Actions'ın yeşil sonuç vermesi beklenmelidir.
